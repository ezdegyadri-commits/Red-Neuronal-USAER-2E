# Paquete reversible USAER 2E 2.0

Destino de referencia: `https://uwoyjp64-fastapi-usaer-2e-2-0.apps-2.websson.cloud/`.
El ZIP contiene un delta con manifiesto SHA-256, código y pruebas ficticias. No contiene PostgreSQL, credenciales, datos de estudiantes, semillas ni el adaptador `~/app/main.py`. No se ha aplicado a Uppcoder. No usar el antiguo autoactualizador.

1. Copiar el ZIP y contrastar su SHA-256 entregado por canal autorizado. Extraer en una carpeta privada, nunca dentro del clon en servicio. Ejecutar en la terminal de mantenimiento:
   ```bash
   umask 077
   USAER_ZIP=/ruta/privada/USAER_2E_CIERRE_OPERATIVO.zip
   python3 codigo/tools/paquete_cierre.py verificar --uppcoder --repo "$HOME/app/usaer2e" --paquete "$USAER_ZIP"
   python3 codigo/tools/paquete_cierre.py preparar --uppcoder --repo "$HOME/app/usaer2e" --paquete "$USAER_ZIP" --parche /ruta/privada/actualizacion.patch
   ```
   Si las huellas de los archivos afectados no coinciden con una de las bases reconocidas, detenerse. Conservar cambios locales y adaptador. No continuar si el adaptador en uso contiene credenciales en código, ejecuta reconciliaciones o no se conoce la forma de recuperar el proceso. El paquete no reemplaza ni ejecuta ese adaptador.
2. Antes de aplicar, obtener respaldo PostgreSQL cifrado con el procedimiento de custodia aprobado, excluyendo datos de sesión e intentos de acceso. Comprobar restauración en una base independiente con PostgreSQL 17. Si en el futuro se restaura un respaldo para atender tráfico, rotar el secreto de sesiones antes de iniciar FastAPI para invalidar todo token anterior a la restauración. Este paquete no ejecuta migraciones ni requiere nuevas tablas: comprobar que el esquema existente ya tiene `colecciones_institucionales` y las tablas de la SPA. Registrar la huella del respaldo y comparar conteos no sensibles. Sin respaldo restaurado, detenerse.
3. Solo tras autorización y dentro de la ventana de mantenimiento, detener FastAPI mediante el supervisor del proveedor. Ejecutar `git -C "$HOME/app/usaer2e" apply --check /ruta/privada/actualizacion.patch` y, si pasa, `git -C "$HOME/app/usaer2e" apply /ruta/privada/actualizacion.patch`. No usar `git reset`, no instalar otro servidor y no tocar `~/app/main.py`. Volver a iniciar FastAPI con el supervisor existente.
4. Comprobar por HTTPS el HTML, JavaScript y acceso autenticado. Abrir un expediente ficticio, editar una planeación de prueba, reabrirla, exportarla y cerrar sesión. Si falla, detener FastAPI y ejecutar `git -C "$HOME/app/usaer2e" apply -R --check /ruta/privada/actualizacion.patch` y después `git -C "$HOME/app/usaer2e" apply -R /ruta/privada/actualizacion.patch`. Arrancar la versión anterior y comprobarla por HTTPS. La reversión de código no restaura ni sobrescribe PostgreSQL.
