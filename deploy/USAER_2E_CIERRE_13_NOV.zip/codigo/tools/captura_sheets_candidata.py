"""Adquisición local de dos lecturas coincidentes, sin permiso de escritura en Sheets."""
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
import re
from time import sleep

from tools.ampliar_recuperacion_historica import CRONOGRAMAS_PUBLICADOS, VERSIONES
from tools.recuperacion_documental import IDS_COLUMNAS, LIBRO_MAESTRO, Incompatible, _filas, _huella, _texto

SCOPE = "https://www.googleapis.com/auth/spreadsheets.readonly"
API = "https://sheets.googleapis.com/v4/spreadsheets/"
IDENTIDADES = {"Alumnos": ("ID_Alumno",), "Escuelas": ("ID_Escuela",),
               "Asignaciones": ("ID_Asignacion",), "Movimientos_Alumnos": ("ID_Movimiento",)}
DIARIOS = {"Planeaciones_Versiones", "EPP_Versiones"}
TABS = {
    "maestro": tuple(dict.fromkeys((*LIBRO_MAESTRO, *IDENTIDADES))),
    "cronogramas": ("Registros",),
}
REQUERIDAS = {"maestro": {"Alumnos", "Planeaciones_Versiones", "EPP_Versiones"}, "cronogramas": {"Registros"}}
MAX_COLUMNAS = 128
MAX_FILAS = 50000
MAX_BYTES = 8 * 1024 * 1024


@dataclass(frozen=True)
class Captura:
    fuente: str
    modo: str
    fecha: str
    hojas: dict
    ausentes: tuple
    huella: str


def _columnas(n):
    letras = ""
    while n:
        n, i = divmod(n - 1, 26)
        letras = chr(65 + i) + letras
    return letras


def _formar_filas(header, filas):
    header = [_texto(c).strip() for c in header]
    nombres = [c for c in header if c]
    if len(nombres) != len(set(nombres)):
        raise Incompatible("encabezados_duplicados")
    for f in filas:
        if any(v not in ("", None) and (i >= len(header) or not header[i]) for i, v in enumerate(f)):
            raise Incompatible("columna_con_datos_sin_encabezado")
        if any(v not in ("", None) for v in f):
            yield {c: _texto(f[i]) if i < len(f) else "" for i, c in enumerate(header) if c}


def _grupos(nombre, filas):
    if nombre == CRONOGRAMAS_PUBLICADOS:
        columnas = ("ID_Publicacion", "Especialista")
    else:
        columnas = IDENTIDADES.get(nombre) or VERSIONES.get(nombre) or (
            (IDS_COLUMNAS[nombre],) if nombre in IDS_COLUMNAS else ())
    grupos = defaultdict(list)
    for fila in filas:
        clave = tuple(fila.get(k, "") for k in columnas)
        grupos[clave if clave and all(clave) else ("", _huella(fila))].append(fila)
    return grupos


def _reconocer(libro, hojas):
    if not REQUERIDAS[libro] <= hojas.keys():
        raise Incompatible("faltan_pestañas_indispensables_" + libro)


def capturas_xlsx(rutas):
    """Una copia local fija puede establecer referencia, nunca fecha de corte en vivo."""
    from openpyxl import load_workbook
    salida = []
    for libro, ruta in rutas.items():
        wb = load_workbook(ruta, read_only=True, data_only=True, keep_links=False)
        try:
            elegidas = {n: _filas(wb[n]) for n in TABS[libro] if n in wb.sheetnames}
            _reconocer(libro, elegidas)
            salida.append(_formar(libro, "xlsx", elegidas))
        finally:
            wb.close()
    return salida


def _formar(libro, modo, elegidas):
    fecha = datetime.now(timezone.utc).isoformat(timespec="seconds")
    ausentes = tuple(n for n in TABS[libro] if n not in elegidas)
    hojas = {CRONOGRAMAS_PUBLICADOS if libro == "cronogramas" else n:
             _grupos(CRONOGRAMAS_PUBLICADOS if libro == "cronogramas" else n, filas)
             for n, filas in elegidas.items()}
    return Captura(libro, modo, fecha, hojas, ausentes, _huella(elegidas))


def _rangos_valores(get, sid, titulo, intervalos, cols):
    esc = "'" + titulo.replace("'", "''") + "'"
    rangos = [f"{esc}!A{inicio}:{_columnas(cols)}{fin}" for inicio, fin in intervalos]
    res = get(sid + "/values:batchGet", ranges=rangos, valueRenderOption="FORMATTED_VALUE", majorDimension="ROWS")
    resultados = res.get("valueRanges", [])
    if res.get("spreadsheetId") != sid or len(resultados) != len(intervalos):
        raise Incompatible("respuesta_sheets_incompleta")
    for (inicio, fin), resultado in zip(intervalos, resultados):
        hoja, _, rango = resultado.get("range", "").rpartition("!")
        if hoja.strip("'").replace("''", "'") != titulo or not re.fullmatch(
            rf"A{inicio}(?::{_columnas(cols)}{fin})?", rango
        ):
            raise Incompatible("rango_sheets_inconsistente")
        celdas = resultado.get("values", [])
        if not isinstance(celdas, list) or len(celdas) > fin - inicio + 1:
            raise Incompatible("respuesta_sheets_fuera_del_rango")
        yield celdas


def una_lectura(get, sid, libro):
    if not re.fullmatch(r"[A-Za-z0-9_-]{20,160}", sid):
        raise Incompatible("identificador_sheets_invalido")
    met = get(sid, fields="spreadsheetId,sheets(properties(sheetId,title,sheetType,gridProperties(rowCount,columnCount)))")
    if met.get("spreadsheetId") != sid:
        raise Incompatible("identificador_sheets_inconsistente")
    mapa = {s["properties"]["title"]: s["properties"] for s in met["sheets"]}
    _reconocer(libro, mapa)
    hojas, ids = {}, {}
    for nombre in TABS[libro]:
        if nombre not in mapa:
            continue
        prop = mapa[nombre]
        cuad = prop.get("gridProperties", {})
        alto, ancho = cuad.get("rowCount", 0), cuad.get("columnCount", 0)
        if not (1 <= alto <= MAX_FILAS and 1 <= ancho <= MAX_COLUMNAS):
            raise Incompatible("dimensiones_fuera_del_limite_" + nombre)
        cabeza = next(_rangos_valores(get, sid, nombre, [(1, 1)], ancho))
        header = cabeza[0] if cabeza else []
        registros = []
        # Se revisa toda la cuadrícula declarada en bloques, incluso si hay huecos.
        extenso = nombre in DIARIOS or nombre in {"Archivos_Expediente", "Borradores_Cronogramas",
                    "Borradores_Horarios", "Tramites_Adjuntos"}
        lote = max(8, min(30 if extenso else 150, 10000 // ancho))
        intervalos = [(inicio, min(alto, inicio + lote - 1)) for inicio in range(2, alto + 1, lote)]
        simultaneos = 3 if extenso else 18
        for i in range(0, len(intervalos), simultaneos):
            for filas in _rangos_valores(get, sid, nombre, intervalos[i:i + simultaneos], ancho):
                registros.extend(_formar_filas(header, filas))
        hojas[nombre] = registros
        ids[nombre] = prop["sheetId"]
    return hojas, ids


def lecturas_consistentes(get, libros, intentos=3):
    for _ in range(intentos):
        a = {tipo: una_lectura(get, sid, tipo) for tipo, sid in libros.items()}
        b = {tipo: una_lectura(get, sid, tipo) for tipo, sid in libros.items()}
        if all(_huella(a[t]) == _huella(b[t]) for t in a):
            return [_formar(t, "sheets", datos[0]) for t, datos in b.items()]
    raise Incompatible("origen_cambio_durante_la_lectura_no_se_aplico_el_corte")


def desde_google(credencial, libros):
    """Solo una cuenta de servicio designada; no usa credenciales del sitio ni del entorno."""
    from google.auth.transport.requests import Request
    from google.oauth2.service_account import Credentials
    import requests

    if not credencial.is_file() or credencial.resolve().drive.upper() != "V:":
        raise Incompatible("credencial_lectura_debe_estar_en_V")
    datos = json.loads(credencial.read_text(encoding="utf-8"))
    if (datos.get("type") != "service_account" or datos.get("token_uri") != "https://oauth2.googleapis.com/token"
            or datos.get("universe_domain", "googleapis.com") != "googleapis.com"):
        raise Incompatible("credencial_google_no_admitida")
    token = Credentials.from_service_account_info(datos, scopes=[SCOPE])
    with requests.Session() as http:
        http.trust_env = False
        transport = Request(session=http)

        def get(path, **params):
            for intento in range(5):
                if not token.valid:
                    token.refresh(transport)
                with http.get(API + path, params=params, timeout=(8, 45), stream=True,
                              allow_redirects=False, headers={"Authorization": "Bearer " + token.token}) as r:
                    if r.status_code == 200:
                        contenido = bytearray()
                        for parte in r.iter_content(65536):
                            contenido.extend(parte)
                            if len(contenido) > MAX_BYTES:
                                raise Incompatible("bloque_sheets_demasiado_grande")
                        return json.loads(contenido)
                    if r.status_code not in {429, 500, 502, 503, 504} or intento == 4:
                        raise Incompatible(f"sheets_lectura_http_{r.status_code}")
                sleep(2 ** intento)
            raise Incompatible("sheets_sin_respuesta")

        return lecturas_consistentes(get, libros)
