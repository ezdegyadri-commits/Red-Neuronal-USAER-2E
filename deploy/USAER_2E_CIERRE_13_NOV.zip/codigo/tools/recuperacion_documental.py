"""Conciliación local de los diarios originales de Streamlit, sin conexiones a Sheets."""
import argparse
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, datetime
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
from uuid import uuid4


LIBRO_MAESTRO = (
    "Planeaciones_Versiones", "EPP_Versiones", "EPP_Programacion", "Anexo3_Deteccion",
    "Anexo4_Sugerencias", "Anexo5_Eventos", "Anexo7_Derivacion", "Expedientes",
    "Relaciones_Expediente", "Linea_Tiempo", "Documentos_Expediente", "Archivos_Expediente",
    "Sintesis_Documentos", "Registro_Visitas", "Oficios_Comision", "Configuracion_Oficios",
    "Horarios_Apoyo", "Horarios_Restricciones", "Borradores_Horarios", "Borradores_Cronogramas",
    "Avisos_Cronogramas", "Relatorias", "Tramites_Expedientes", "Tramites_Adjuntos",
    "Juntas_Academicas_Versiones", "Metas_Personales_Versiones",
)
PLAN_CAMPOS = ("Documento", "Revision", "Anterior", "Fecha", "Cuenta", "Autor", "Escuela_ID",
               "Alumnos_JSON", "Formato", "Estado", "Total", "SHA256")
EPP_CAMPOS = ("Alumno", "Ciclo", "Parte", "Revision", "Anterior", "Fecha",
              "Cuenta", "Autor", "Estado", "Contenido")
AREAS = {"META", "Aprendizaje", "Psicología", "Comunicación", "Trabajo Social", "Conclusión"}
IDS_COLUMNAS = {
    "Anexo3_Deteccion": "ID_Anexo3", "Anexo4_Sugerencias": "ID_Anexo4",
    "Anexo5_Eventos": "ID_Evento", "Anexo7_Derivacion": "ID_Anexo7", "Expedientes": "ID_Expediente",
    "Relaciones_Expediente": "ID_Relacion", "Linea_Tiempo": "ID_Evento_Timeline",
    "Documentos_Expediente": "ID_Documento", "Registro_Visitas": "ID_Visita",
    "Oficios_Comision": "ID_Oficio", "Configuracion_Oficios": "ID_Configuracion",
}


class Incompatible(ValueError):
    """Código de conciliación sin contenido ni identificadores personales."""


def _exigir(condicion, motivo):
    if not condicion:
        raise Incompatible(motivo)


def _texto(valor):
    return valor.isoformat() if isinstance(valor, (date, datetime)) else str(valor) if valor is not None else ""


def _json(raw, tipo):
    try:
        valor = json.loads(raw)
    except (TypeError, ValueError, RecursionError):
        raise Incompatible("json_invalido") from None
    _exigir(isinstance(valor, tipo), "estructura_invalida")
    return valor


def _serializar(valor):
    return json.dumps(valor, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _huella(valor):
    return sha256(_serializar(valor).encode()).hexdigest()


def _filas(hoja):
    filas = hoja.values
    encabezado = [_texto(v).strip() for v in next(filas, ())]
    columnas = [v for v in encabezado if v]
    _exigir(len(columnas) == len(set(columnas)), "encabezados_duplicados")
    return [{k: _texto(v) for k, v in zip(encabezado, fila) if k}
            for fila in filas if any(v not in (None, "") for v in fila)]


def _cadena(versiones, anterior):
    """Valida una raíz y una sola línea de revisiones; el orden no depende del reloj."""
    siguiente = {}
    for revision in versiones:
        previo = anterior(versiones[revision])
        _exigir(not previo or previo in versiones, "revision_anterior_faltante")
        _exigir(previo not in siguiente, "revisiones_en_rama")
        siguiente[previo] = revision
    orden = []
    rev = siguiente.get("")
    while rev:
        orden.append(rev)
        rev = siguiente.get(rev)
    _exigir(len(orden) == len(versiones), "cadena_discontinua")
    return orden


def reconstruir_planeacion(filas, *, exigir_cadena=True):
    grupos = defaultdict(list)
    for fila in filas:
        revision = fila.get("Revision", "").strip()
        _exigir(bool(revision), "revision_sin_id")
        grupos[revision].append(fila)
    versiones = {}
    for revision, fragmentos in grupos.items():
        base = fragmentos[0]
        _exigir(all(base.get(k) for k in PLAN_CAMPOS if k != "Anterior"), "metadatos_incompletos")
        try:
            total = int(base["Total"])
            partes = {}
            for fila in fragmentos:
                _exigir(all(fila.get(k) == base.get(k) for k in PLAN_CAMPOS), "fragmentos_contradictorios")
                indice = int(fila.get("Parte", ""))
                texto = fila.get("Contenido", "")
                _exigir(indice not in partes or partes[indice] == texto, "fragmento_duplicado_distinto")
                partes[indice] = texto
        except ValueError as exc:
            if isinstance(exc, Incompatible):
                raise
            raise Incompatible("indice_o_total_invalido") from None
        _exigir(1 <= total <= 12 and set(partes) == set(range(total)), "fragmentos_incompletos")
        payload = "".join(partes[i] for i in range(total))
        _exigir(sha256(payload.encode()).hexdigest() == base["SHA256"], "huella_no_coincide")
        doc = _json(payload, dict)
        _exigir(all(doc.get(k) == base[c] for k, c in (
            ("id", "Documento"), ("cuenta", "Cuenta"), ("formato", "Formato"), ("estado", "Estado")
        )), "identidad_payload_distinta")
        datos = doc.get("datos")
        _exigir(isinstance(datos, dict), "datos_incompletos")
        ids = _json(base["Alumnos_JSON"], list)
        alumnos = datos.get("Alumnos")
        _exigir(isinstance(alumnos, list) and all(isinstance(a, dict) for a in alumnos), "matricula_invalida")
        ids_datos = [a.get("ID_Alumno") for a in alumnos]
        _exigir(bool(ids) and all(isinstance(i, str) and i.strip() for i in ids)
                and all(isinstance(i, str) and i.strip() for i in ids_datos)
                and len(ids) == len(set(ids)) == len(ids_datos) and set(ids) == set(ids_datos)
                and datos.get("ID_Escuela") == base["Escuela_ID"], "matricula_o_escuela_inconsistente")
        doc.update(revision=revision, anterior=base.get("Anterior", ""), guardado_en=base["Fecha"])
        versiones[revision] = (doc, {"fuente": "Planeaciones_Versiones", "autor": base["Autor"],
                                    "cuenta": base["Cuenta"], "sha256": base["SHA256"]})
    orden = _cadena(versiones, lambda v: v[0]["anterior"]) if exigir_cadena else versiones
    return [versiones[r] for r in orden]


def reconstruir_epp(filas):
    alumno, ciclo = filas[0].get("Alumno", ""), filas[0].get("Ciclo", "")
    _exigir(bool(alumno) and bool(re.fullmatch(r"20\d\d-20\d\d", ciclo))
            and int(ciclo[-4:]) == int(ciclo[:4]) + 1, "alumno_o_ciclo_invalido")
    from services.epp_modelo import clave
    eid = clave(alumno, ciclo)
    partes, eventos, versiones = {}, {}, []
    for fila in filas:
        area, revision = fila.get("Parte", ""), fila.get("Revision", "")
        _exigir(area in AREAS and all(fila.get(k) for k in ("Revision", "Fecha", "Cuenta", "Autor", "Estado")),
                "metadatos_incompletos")
        firma = _huella({k: fila.get(k, "") for k in EPP_CAMPOS})
        if revision in eventos:
            _exigir(eventos[revision] == firma, "revision_duplicada_distinta")
            continue
        _exigir(fila.get("Anterior", "") == partes.get(area, {}).get("revision", ""), "cadena_de_area_discontinua")
        eventos[revision] = firma
        partes[area] = {"contenido": _json(fila.get("Contenido"), dict), "revision": revision,
                        "anterior": fila.get("Anterior", ""), "fecha": fila["Fecha"], "autor": fila["Autor"],
                        "cuenta": fila["Cuenta"], "estado": fila["Estado"]}
        _exigir("META" in partes, "epp_sin_apertura")
        versiones.append(({"id": eid, "alumno": alumno, "ciclo": ciclo, "partes": dict(partes),
                           "revision": revision, "fecha": fila["Fecha"]},
                          {"fuente": "EPP_Versiones", "autor": fila["Autor"], "cuenta": fila["Cuenta"],
                           "parte": area, "sha256": firma}))
    return versiones


@dataclass
class Documento:
    tipo: str
    versiones: list

    @property
    def vigente(self):
        return self.versiones[-1][0]


def inspeccionar(ruta):
    from openpyxl import load_workbook
    libro = load_workbook(ruta, read_only=True, data_only=True, keep_links=False)
    try:
        conteos, documentos, identidades = {}, [], {}
        for nombre in LIBRO_MAESTRO:
            if nombre not in libro.sheetnames:
                conteos[nombre] = {"estado": "pestana_no_incluida"}
                continue
            filas = _filas(libro[nombre])
            conteos[nombre] = reporte = {"filas": len(filas)}
            if columna := IDS_COLUMNAS.get(nombre):
                ids = Counter(r[columna] for r in filas if r.get(columna))
                identidades[nombre] = {i for i, n in ids.items() if n == 1}
                reporte.update(ids_unicos=len(identidades[nombre]),
                               ids_repetidos=sum(n > 1 for n in ids.values()),
                               filas_sin_id=sum(not r.get(columna) for r in filas))
            if nombre not in ("Planeaciones_Versiones", "EPP_Versiones"):
                continue
            plan = nombre == "Planeaciones_Versiones"
            grupos = defaultdict(list)
            incompletas = 0
            for fila in filas:
                clave = (fila.get("Documento", ""),) if plan else (fila.get("Alumno", ""), fila.get("Ciclo", ""))
                if not all(clave):
                    incompletas += 1
                    continue
                grupos[clave].append(fila)
            motivos, modos = Counter(), Counter()
            for grupo in grupos.values():
                try:
                    versiones = reconstruir_planeacion(grupo) if plan else reconstruir_epp(grupo)
                except Incompatible as exc:
                    motivos[str(exc)] += 1
                    continue
                documento = Documento("planeaciones" if plan else "epp", versiones)
                documentos.append(documento)
                if plan:
                    modo = (documento.vigente.get("metadatos") or {}).get("modalidad_planeacion")
                    modos[modo if modo in {"individual", "grupal", "especialista"} else "sin_clasificar"] += 1
            reporte.update(documentos=len(grupos), con_cadena_valida=len(grupos) - sum(motivos.values()),
                           ambiguos=sum(motivos.values()), filas_sin_identidad=incompletas, motivos=dict(motivos))
            if plan:
                reporte["modalidades_con_cadena_valida"] = dict(modos)
        return conteos, documentos, identidades
    finally:
        libro.close()


def destino_candidato(dsn):
    from sqlalchemy.engine import make_url
    url = make_url(dsn)
    _exigir(url.get_backend_name() == "postgresql" and url.host == "127.0.0.1"
            and url.port == 55491 and url.username == "usaer_qa"
            and bool(re.fullmatch(r"usaer_historica_candidata(?:_[a-f0-9]{8})?", url.database or ""))
            and not url.query, "destino_no_es_candidato_local")
    return url


TABLAS_RESPALDO = {
    "anexo3_deteccion": "Anexo3_Deteccion", "anexo4_sugerencias": "Anexo4_Sugerencias",
    "anexo5_eventos": "Anexo5_Eventos", "anexo7_derivacion": "Anexo7_Derivacion",
    "registro_visitas": "Registro_Visitas", "oficios_comision": "Oficios_Comision",
    "configuracion_oficios": "Configuracion_Oficios", "planeaciones": "Planeaciones_Versiones",
    "epp_documentos": "EPP_Versiones", "colecciones_institucionales": "colecciones",
}


def _descifrar_dpapi(path):
    import ctypes
    from ctypes import wintypes

    _exigir(os.name == "nt", "dpapi_requiere_windows")

    class Blob(ctypes.Structure):
        _fields_ = [("length", wintypes.DWORD), ("address", ctypes.c_void_p)]

    cifrado = path.read_bytes()
    buffer = ctypes.create_string_buffer(cifrado)
    origen = Blob(len(cifrado), ctypes.addressof(buffer))
    destino = Blob()
    _exigir(ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(origen), None, None, None, None, 1, ctypes.byref(destino)
    ), "respaldo_no_se_pudo_descifrar_en_esta_sesion")
    try:
        datos = ctypes.string_at(destino.address, destino.length)
        _exigir(datos.startswith(b"PGDMP"), "respaldo_no_es_pg_dump")
        return datos
    finally:
        ctypes.memset(destino.address, 0, destino.length)
        ctypes.windll.kernel32.LocalFree(ctypes.c_void_p(destino.address))


def _copy_valor(valor):
    if valor == r"\N":
        return ""
    caracteres = {"t": "\t", "n": "\n", "r": "\r", "b": "\b", "f": "\f", "v": "\v", "\\": "\\"}
    return re.sub(r"\\([tnrbfv\\])", lambda m: caracteres[m[1]], valor)


def comparar_respaldo(path, pg_restore, documentos, identidades):
    """Lee solo las tablas documentales de un respaldo DPAPI, sin extraer archivos."""
    comando = [str(pg_restore.resolve()), "-a", "-f", "-"]
    for tabla in TABLAS_RESPALDO:
        comando.extend(("-t", tabla))
    proceso = subprocess.run(comando, input=_descifrar_dpapi(path), capture_output=True, timeout=180)
    _exigir(proceso.returncode == 0, "no_se_pudo_leer_respaldo_postgresql")
    conteos, planes, epps, colecciones = Counter(), defaultdict(list), defaultdict(list), Counter()
    ids_respaldo = defaultdict(set)
    tabla, columnas = None, []
    for linea in proceso.stdout.decode("utf-8").split("\n"):
        if tabla:
            if linea.rstrip("\r") == r"\.":
                tabla = None
                continue
            conteos[TABLAS_RESPALDO[tabla]] += 1
            fila = dict(zip(columnas, map(_copy_valor, linea.rstrip("\r").split("\t"))))
            if tabla == "planeaciones":
                planes[fila["id"]].append((fila.get("revision", ""), fila.get("payload_json")))
            elif tabla == "epp_documentos":
                aid = fila["alumno"].removeprefix("epp-").removeprefix("alu-uppcoder-")
                epps[aid, fila["ciclo"]].append((fila.get("revision", ""), fila.get("partes_json")))
            elif tabla == "colecciones_institucionales":
                colecciones["registros"] += 1
            elif fila.get("id"):
                ids_respaldo[TABLAS_RESPALDO[tabla]].add(fila["id"])
        elif match := re.fullmatch(r"COPY public\.([a-z0-9_]+) \(([^)]+)\) FROM stdin;", linea.rstrip("\r")):
            if match[1] in TABLAS_RESPALDO:
                tabla = match[1]
                conteos.setdefault(TABLAS_RESPALDO[tabla], 0)
                columnas = [col.strip(' "') for col in match[2].split(",")]
    cotejo = defaultdict(Counter)
    for doc in documentos:
        vigente = doc.vigente
        plan = doc.tipo == "planeaciones"
        previos = planes.get(vigente["id"], []) if plan else epps.get((vigente["alumno"], vigente["ciclo"]), [])
        total = cotejo[doc.tipo]
        if not previos:
            total["ausentes_por_id"] += 1
        elif len(previos) != 1:
            total["multiples_coincidencias"] += 1
        else:
            revision, contenido = previos[0]
            total["encontrados_por_id"] += 1
            try:
                exacto = (revision == vigente["revision"] and
                          _json(contenido, dict) == (vigente if plan else vigente["partes"]))
            except Incompatible:
                exacto = False
            total["identicos" if exacto else "requieren_conciliacion_de_version"] += 1
    otros = {nombre: {"encontrados_por_id": len(ids & ids_respaldo[nombre]),
                      "ausentes_por_id": len(ids - ids_respaldo[nombre])}
             for nombre, ids in identidades.items() if nombre in conteos}
    return {"filas": dict(conteos), "colecciones": dict(colecciones), "cotejo_otros_por_id": otros,
            "cotejo": {tipo: dict(c) for tipo, c in cotejo.items()}}


def conciliar(db, documentos, *, aplicar=False, administrar_transaccion=True):
    from sqlalchemy import select, text
    from data.database import Alumno, ColeccionInstitucional, EPPDoc, PlaneacionDoc, Usuario

    if administrar_transaccion and aplicar:
        db.execute(text("SELECT pg_advisory_xact_lock(254811623)"))
    elif administrar_transaccion:
        db.execute(text("SET TRANSACTION READ ONLY"))
    padron = dict(db.execute(select(Alumno.id, Alumno.id_escuela)).all())
    cuentas = set(db.execute(select(Usuario.usuario)).scalars())
    planes = {r.id: r for r in db.execute(select(PlaneacionDoc.id, PlaneacionDoc.revision,
                                                 PlaneacionDoc.payload_json))}
    epps = defaultdict(list)
    for r in db.execute(select(EPPDoc.id, EPPDoc.alumno, EPPDoc.ciclo, EPPDoc.revision, EPPDoc.partes_json)):
        aid = r.alumno.removeprefix("epp-").removeprefix("alu-uppcoder-")
        epps[(aid, r.ciclo)].append(r)
    reporte = defaultdict(Counter)
    for doc in documentos:
        vigente = doc.vigente
        stats = reporte[doc.tipo]
        stats["con_cadena_valida"] += 1
        plan = doc.tipo == "planeaciones"
        previos = ([planes[vigente["id"]]] if vigente["id"] in planes else []) if plan else epps.get(
            (vigente["alumno"], vigente["ciclo"]), [])
        if previos:
            stats["en_postgresql"] += 1
            # Misma revisión no basta: una captura local puede haber cambiado su contenido.
            exacto = len(previos) == 1 and previos[0].revision == vigente["revision"]
            if exacto:
                almacenado = _json(previos[0].payload_json if plan else previos[0].partes_json, dict)
                esperado = vigente if plan else vigente["partes"]
                exacto = almacenado == esperado
            stats["conciliados" if exacto else "conflictos_preservados"] += 1
            continue
        stats["faltantes"] += 1
        if any(meta["cuenta"] not in cuentas for _, meta in doc.versiones):
            stats["autor_no_conciliado"] += 1
            continue
        if plan:
            relacion_correcta = all(
                padron.get(a["ID_Alumno"]) == version["datos"]["ID_Escuela"]
                for version, _ in doc.versiones for a in version["datos"]["Alumnos"]
            )
        else:
            relacion_correcta = bool(padron.get(vigente["alumno"]))
        if not relacion_correcta:
            stats["matricula_no_conciliada"] += 1
            continue
        stats["conciliados"] += 1
        if not aplicar:
            continue
        if plan:
            tabla = PlaneacionDoc.__table__
            values = {k: vigente[k] for k in ("id", "cuenta", "formato", "estado", "revision", "guardado_en")}
            values.update({f"{k}_json": _serializar(vigente.get(k, {}))
                           for k in ("datos", "metadatos", "tablas", "textos")})
            values.update(payload_json=_serializar(vigente), observaciones_director=vigente.get("observaciones_director", ""))
        else:
            tabla = EPPDoc.__table__
            values = {k: vigente[k] for k in ("id", "alumno", "ciclo", "revision", "fecha")}
            values.update(estado=vigente["partes"]["META"]["estado"], partes_json=_serializar(vigente["partes"]))
        db.execute(tabla.insert().values(**values))
        modulo = "planeacion_revisiones" if plan else "epp_revisiones"
        for version, meta in doc.versiones[:-1]:
            rid = (f"{version['id']}:{sha256(version['revision'].encode()).hexdigest()[:40]}" if plan
                   else _huella([modulo, version["id"], version["revision"]]))
            snapshot = {**version, "procedencia_historica": meta}
            db.execute(ColeccionInstitucional.__table__.insert().values(
                id=f"{modulo}:{rid}", modulo=modulo, registro_id=rid, cuenta=meta["cuenta"],
                id_alumno=version.get("alumno", ""), fecha=version.get("fecha") or version.get("guardado_en", ""),
                payload_json=_serializar(snapshot),
            ))
        stats["recuperados"] += 1
    return {tipo: dict(c) for tipo, c in reporte.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--libro", required=True, type=Path)
    parser.add_argument("--comparar", action="store_true", help="Lee la base candidata local desde USAER_HISTORICA_DSN.")
    parser.add_argument("--aplicar", action="store_true", help="Inserta únicamente faltantes en una candidata local.")
    parser.add_argument("--ampliar", action="store_true", help="Archiva procedencia y proyecta anexos compatibles.")
    parser.add_argument("--libro-cronogramas", type=Path, help="Copia local del libro separado con pestaña Registros.")
    parser.add_argument("--respaldo-dir", type=Path, help="Carpeta privada cifrada autorizada para un respaldo completo.")
    parser.add_argument("--pg-dump", type=Path)
    parser.add_argument("--respaldo-dpapi", type=Path)
    parser.add_argument("--pg-restore", type=Path)
    args = parser.parse_args()
    try:
        _exigir(not args.ampliar or args.comparar or args.aplicar, "ampliar_requiere_comparar_o_aplicar")
        _exigir(not args.libro_cronogramas or args.ampliar, "libro_cronogramas_requiere_ampliar")
        conteos, docs, identidades = inspeccionar(args.libro)
        salida = {"fuente": "copia_xlsx_local", "pestanas": conteos}
        if args.respaldo_dpapi:
            _exigir(args.pg_restore and args.pg_restore.is_file(), "pg_restore_requerido")
            salida["respaldo_postgresql"] = comparar_respaldo(args.respaldo_dpapi, args.pg_restore, docs, identidades)
        if args.comparar or args.aplicar:
            from sqlalchemy import create_engine
            url = destino_candidato(os.environ.get("USAER_HISTORICA_DSN", ""))
            motor = create_engine(url)
            try:
                if args.aplicar:
                    _exigir(args.respaldo_dir and args.respaldo_dir.is_dir() and args.pg_dump and args.pg_dump.is_file(),
                            "respaldo_cifrado_y_pg_dump_requeridos")
                    _exigir(os.name == "nt" and args.respaldo_dir.resolve().drive.upper() == "V:",
                            "respaldo_requiere_volumen_privado_V")
                    from sqlalchemy import text
                    with motor.connect() as verificacion:
                        pgdata = verificacion.execute(text("SHOW data_directory")).scalar_one()
                    _exigir(Path(pgdata).drive.upper() == "V:", "clúster_candidato_fuera_del_volumen_V")
                    if args.ampliar:
                        _exigir(Path(pgdata) == Path("V:/USAER-Candidata-Historica-2/pgdata"),
                                "clúster_no_corresponde_a_la_candidata_restaurada")
                    respaldo = args.respaldo_dir / f"candidata-antes-{uuid4().hex}.dump"
                    env = dict(os.environ, PGPASSWORD=url.password or os.environ.get("PGPASSWORD", ""))
                    proceso = subprocess.run([str(args.pg_dump.resolve()), "-w", "-h", url.host, "-p", str(url.port),
                                              "-U", url.username, "-Fc", "-f", str(respaldo), url.database],
                                             env=env, capture_output=True, timeout=180)
                    _exigir(proceso.returncode == 0 and respaldo.is_file() and respaldo.stat().st_size > 0,
                            "respaldo_no_confirmado")
                with motor.begin() as db:
                    if args.ampliar:
                        from sqlalchemy import text
                        from sqlalchemy.orm import Session
                        from tools.ampliar_recuperacion_historica import ampliar
                        db.execute(text("SELECT pg_advisory_xact_lock(254811623)" if args.aplicar
                                        else "SET TRANSACTION READ ONLY"))
                        with Session(bind=db) as sesion:
                            salida["ampliacion"] = ampliar(sesion, args.libro, aplicar=args.aplicar,
                                                           cronogramas=args.libro_cronogramas)
                    else:
                        salida["postgresql"] = conciliar(db, docs, aplicar=args.aplicar)
            finally:
                motor.dispose()
        print(_serializar(salida))
    except Incompatible as exc:
        raise SystemExit(f"Conciliación detenida: {exc}") from None
    except Exception:
        raise SystemExit("Conciliación detenida por un error de lectura o de base de datos. No se muestran datos privados.") from None


if __name__ == "__main__":
    main()
