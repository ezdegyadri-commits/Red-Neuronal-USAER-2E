"""Segunda capa de recuperación: archivo de procedencia y proyección sin reemplazos."""
import base64
import binascii
from collections import Counter, defaultdict
from hashlib import sha256

from sqlalchemy import select, String
from sqlalchemy.dialects.postgresql import insert

from data.database import (
    Alumno, Anexo3Deteccion, Anexo4Sugerencia, Anexo5Evento, Anexo7Derivacion,
    ColeccionInstitucional, Escuela,
)
from tools.recuperacion_documental import (
    IDS_COLUMNAS, LIBRO_MAESTRO, Incompatible, _exigir, _filas, _huella, _json, _serializar,
    reconstruir_epp, reconstruir_planeacion,
)

ARCHIVO = "archivo_historico_streamlit"
CRONOGRAMAS_PUBLICADOS = "Cronogramas_Registros"
VERSIONES = {
    "Planeaciones_Versiones": ("Documento",),
    "EPP_Versiones": ("Alumno", "Ciclo"),
    "Archivos_Expediente": ("ID_Documento",),
    "Horarios_Apoyo": ("ID_Version", "ID_Escuela", "Maestra"),
    "Horarios_Restricciones": ("ID_Version", "ID_Escuela"),
    "Borradores_Horarios": ("ID_Version", "Maestra", "Escuela"),
    "Borradores_Cronogramas": ("ID_Version", "Especialista", "Mes"),
    "Avisos_Cronogramas": ("ID_Aviso",),
    "Juntas_Academicas_Versiones": ("Documento",),
    "Metas_Personales_Versiones": ("Documento",),
    "Tramites_Expedientes": ("ID_Tramite",),
    "Tramites_Adjuntos": ("ID_Tramite", "ID_Adjunto"),
}
ANEXOS = {
    "Anexo3_Deteccion": (Anexo3Deteccion, {"id_personal": "ID_Personal", "fecha": "Fecha",
        "bap_fisicas": "BAP_Fisicas", "bap_actitudinales": "BAP_Actitudinales",
        "bap_pedagogicas": "BAP_Pedagogicas", "bap_organizativas": "BAP_Organizativas",
        "estatus_ia": "Estatus_IA", "estado": "Estado"}),
    "Anexo4_Sugerencias": (Anexo4Sugerencia, {"fecha_elaboracion": "Fecha_Elaboracion",
        "docente_especialista": "Quien_Brinda_Sugerencias", "sugerencias_area": "Sugerencias_Area",
        "motivo": "Motivo", "sugerencias": "Sugerencias", "fecha_seguimiento": "Fecha_Seguimiento",
        "nivel_cumplimiento_resultados": "Nivel_Cumplimiento_Resultados", "estado": "Estado"}),
    "Anexo5_Eventos": (Anexo5Evento, {"fecha": "Fecha", "nombre_alumno": "Nombre_Alumno",
        "grado_grupo": "Grado_Grupo", "especialista": "Especialista", "evento": "Evento",
        "estado": "Estado", "id_escuela": "ID_Escuela", "escuela": "Escuela"}),
    "Anexo7_Derivacion": (Anexo7Derivacion, {"fecha": "Fecha", "escuela": "Escuela",
        "docente_regular": "Docente_Regular", "fecha_nacimiento": "Fecha_Nacimiento",
        "respuestas_json": "Respuestas_JSON", "salud": "Salud", "seguimiento_medico": "Seguimiento_Medico",
        "aspecto_relevante": "Aspecto_Relevante", "elaborado_por": "Elaborado_Por"}),
}
FECHAS = ("Fecha", "Fecha_Elaboracion", "Fecha_Apertura", "Guardado_En", "Fecha_Emision")


def validar_adjunto(ficha, fragmentos):
    try:
        n = int(ficha["Partes"])
        partes = {int(f["Indice"]): f for f in fragmentos}
        _exigir(1 <= n <= 234 and len(fragmentos) == n and set(partes) == set(range(n)) and all(
            f["ID_Documento"] == ficha["ID_Documento"] and int(f["Total"]) == n and len(f["Contenido"]) <= 30000
            for f in fragmentos), "fragmentos_adjunto_incompletos_o_duplicados")
        data = base64.b64decode("".join(partes[i]["Contenido"] for i in range(n)), validate=True)
    except (KeyError, TypeError, ValueError, binascii.Error) as exc:
        if isinstance(exc, Incompatible):
            raise
        raise Incompatible("fragmentos_adjunto_invalidos") from None
    _exigir(0 < len(data) <= 5 * 1024 * 1024 and sha256(data).hexdigest() == ficha.get("SHA256"),
            "huella_adjunto_no_coincide")
    firmas = {"application/pdf": b"%PDF-", "image/jpeg": b"\xff\xd8\xff", "image/png": b"\x89PNG\r\n\x1a\n"}
    firma = firmas.get(ficha.get("Mime"))
    _exigir(firma and data.startswith(firma), "tipo_adjunto_no_verificado")
    return data


def leer_grupos(libro):
    """Las filas se guardan íntegras; un ID repetido no elige un ganador."""
    from openpyxl import load_workbook
    xlsx = load_workbook(libro, read_only=True, data_only=True, keep_links=False)
    try:
        for nombre in LIBRO_MAESTRO:
            if nombre not in xlsx.sheetnames:
                continue
            columnas = VERSIONES.get(nombre) or ((IDS_COLUMNAS[nombre],) if nombre in IDS_COLUMNAS else ())
            grupos = defaultdict(list)
            for fila in _filas(xlsx[nombre]):
                clave = tuple(fila.get(c, "") for c in columnas)
                grupos[clave if clave and all(clave) else ("", _huella(fila))].append(fila)
            yield nombre, grupos
    finally:
        xlsx.close()


def leer_cronogramas_publicados(libro):
    """Solo la pestaña Registros del libro separado; jamás consulta Google."""
    from openpyxl import load_workbook
    xlsx = load_workbook(libro, read_only=True, data_only=True, keep_links=False)
    try:
        _exigir("Registros" in xlsx.sheetnames, "cronogramas_sin_pestana_registros")
        hoja = xlsx["Registros"]
        columnas = next(hoja.values, ())
        _exigir({"Especialista", "Fecha", "Escuela", "Actividad"}.issubset(columnas),
                "cronogramas_encabezado_incompatible")
        grupos = defaultdict(list)
        for fila in _filas(hoja):
            clave = (fila.get("ID_Publicacion", ""), fila.get("Especialista", ""))
            grupos[clave if all(clave) else ("", _huella(fila))].append(fila)
        return grupos
    finally:
        xlsx.close()


def _guardar(db, tabla, valores, aplicar):
    if not aplicar:
        return True
    return bool(db.execute(insert(tabla).values(**valores).on_conflict_do_nothing(
        index_elements=[tabla.c.id]).returning(tabla.c.id)).scalar_one_or_none())


def _destino_individual(fila, padron, escuelas):
    aid = fila.get("ID_Alumno", "")
    alumno = padron.get(aid)
    _exigir(alumno is not None and alumno.id_escuela in escuelas and
            alumno.estatus != "ANULADO_MIGRACION" and not aid.startswith(("GRUPO-", "alu-uppcoder-")),
            "matricula_o_grupo_no_conciliado")
    escuela = fila.get("ID_Escuela", "")
    _exigir(not escuela or escuela == alumno.id_escuela, "escuela_no_conciliada")
    nombre = fila.get("Escuela", "").strip().casefold()
    _exigir(not nombre or nombre in {escuelas[alumno.id_escuela].strip().casefold(),
                                    (alumno.nombre_escuela or "").strip().casefold()}, "escuela_no_conciliada")
    return alumno


def _anexo(nombre, fila, padron, escuelas):
    modelo, campos = ANEXOS[nombre]
    alumno = _destino_individual(fila, padron, escuelas)
    tabla = modelo.__table__
    valores = {dest: fila.get(orig, "") for dest, orig in campos.items()}
    valores.update(id=fila[IDS_COLUMNAS[nombre]], id_alumno=alumno.id)
    if nombre == "Anexo4_Sugerencias":
        valores["observaciones"] = _serializar({
            "nombre_alumno": fila.get("Nombre_Alumno", ""), "escuela": fila.get("Escuela", ""),
            "grado_grupo": fila.get("Grado_Grupo", ""), "servicio_ee": fila.get("Servicio_EE", ""),
        })
    if nombre == "Anexo7_Derivacion" and valores["respuestas_json"]:
        _json(valores["respuestas_json"], dict)
    _exigir(all(len(v) <= tabla.c[k].type.length for k, v in valores.items()
                if isinstance(tabla.c[k].type, String) and tabla.c[k].type.length),
            "campo_excede_esquema_operativo")
    return tabla, valores


def _registro_archivo(nombre, clave, filas, estado, *, extra=None):
    huella = _huella([nombre, clave, filas])
    doc = {"pestana": nombre, "clave": list(clave), "sha256": huella, "filas": filas}
    if extra:
        doc.update(extra)
    return dict(id=f"{ARCHIVO}:{huella}", modulo=ARCHIVO, registro_id=f"{nombre}:{huella}",
                estado=estado, fecha=next((filas[0].get(c) for c in FECHAS if filas[0].get(c)), "")[:64],
                payload_json=_serializar(doc))


def _estado_diario(nombre, filas):
    if nombre == "Planeaciones_Versiones":
        try:
            versiones = reconstruir_planeacion(filas)
        except Incompatible as exc:
            # Incluso si el diario no tiene una única cabeza, se rescatan los nodos
            # íntegros por separado. Ninguno se designa vigente.
            motivos, nodos = Counter(), []
            grupos = defaultdict(list)
            for fila in filas:
                grupos[fila.get("Revision", "")].append(fila)
            for grupo in grupos.values():
                try:
                    nodos.extend(reconstruir_planeacion(grupo, exigir_cadena=False))
                except Incompatible as detalle:
                    motivos[str(detalle)] += 1
            return str(exc), {"revisiones_verificadas": nodos, "revisiones_no_verificadas": dict(motivos)}
        return "diario_planeacion", {"revisiones_verificadas": len(versiones)}
    if nombre == "EPP_Versiones":
        try:
            versiones = reconstruir_epp(filas)
        except Incompatible as exc:
            return str(exc), {}
        return "diario_epp", {"revisiones_verificadas": len(versiones)}
    return "pendiente_proyeccion", {}


def ampliar(db, libro=None, *, aplicar=False, cronogramas=None, capturados=None):
    padron = {a.id: a for a in db.scalars(select(Alumno))}
    escuelas = dict(db.execute(select(Escuela.id, Escuela.nombre_escuela)).all())
    archivo = ColeccionInstitucional.__table__
    archivados = set(db.scalars(select(archivo.c.registro_id).where(archivo.c.modulo == ARCHIVO)))
    existentes = {nombre: {r.id: r for r in db.scalars(select(modelo))}
                  for nombre, (modelo, _) in ANEXOS.items()}
    grupos_libro = dict(leer_grupos(libro)) if capturados is None else capturados
    if cronogramas is not None:
        grupos_libro[CRONOGRAMAS_PUBLICADOS] = leer_cronogramas_publicados(cronogramas)
    cabeceras = grupos_libro.get("Expedientes", {})
    tiempo = {r.registro_id: r for r in db.scalars(select(ColeccionInstitucional).where(
        ColeccionInstitucional.modulo == "linea_tiempo"))}
    reportes = {}
    for nombre, grupos in grupos_libro.items():
        reporte = Counter()
        for clave, filas in grupos.items():
            reporte["filas_fuente"] += len(filas)
            reporte["grupos_fuente"] += 1
            estado, extra = _estado_diario(nombre, filas)
            if nombre in ANEXOS:
                if not clave[0]:
                    estado = "id_faltante"
                elif len(filas) > 1 and any(f != filas[0] for f in filas[1:]):
                    estado = "id_repetido_con_contenido_distinto"
                else:
                    if len(filas) > 1:
                        reporte["copias_identicas"] += len(filas) - 1
                    try:
                        tabla, valores = _anexo(nombre, filas[0], padron, escuelas)
                        previo = existentes[nombre].get(valores["id"])
                        if previo is not None:
                            iguales = all((getattr(previo, k) or "") == v for k, v in valores.items())
                            estado = "operativo_identico" if iguales else "id_existente_diferente"
                        elif _guardar(db, tabla, valores, aplicar):
                            estado = "incorporado" if aplicar else "incorporable"
                        else:
                            estado = "id_existente_concurrente"
                    except Incompatible as exc:
                        estado = str(exc)
            if nombre == "Documentos_Expediente" and len(filas) == 1 and clave[0]:
                try:
                    validar_adjunto(filas[0], grupos_libro.get("Archivos_Expediente", {}).get(clave, []))
                    estado = "adjunto_con_binario_verificado"
                    extra = {"fragmentos_ref": _registro_archivo(
                        "Archivos_Expediente", clave, grupos_libro["Archivos_Expediente"][clave], "")["id"]}
                except Incompatible as exc:
                    estado = str(exc)
            if nombre == "Linea_Tiempo":
                fila = filas[0]
                try:
                    _exigir(bool(clave[0]), "id_faltante")
                    _exigir(all(f == fila for f in filas), "id_repetido_con_contenido_distinto")
                    alumno = _destino_individual(fila, padron, escuelas)
                    padres = cabeceras.get((fila.get("ID_Expediente", ""),), [])
                    _exigir(len(padres) == 1 and padres[0].get("ID_Alumno") == alumno.id,
                            "expediente_no_conciliado")
                    rid = clave[0]
                    _exigir(len(rid) <= 115, "campo_excede_esquema_operativo")
                    if previo := tiempo.get(rid):
                        estado = ("operativo_identico" if previo.id_alumno == alumno.id and
                                  _json(previo.payload_json, dict) == fila else "id_existente_diferente")
                    else:
                        alta = _guardar(db, archivo, dict(id=f"linea_tiempo:{rid}", modulo="linea_tiempo",
                            registro_id=rid, id_escuela=alumno.id_escuela, id_alumno=alumno.id,
                            fecha=fila.get("Fecha", "")[:64], payload_json=_serializar(fila)), aplicar)
                        estado = ("incorporado" if aplicar else "incorporable") if alta else "id_existente_concurrente"
                except Incompatible as exc:
                    estado = str(exc)
            reporte[estado] += 1
            evidencia = _registro_archivo(nombre, clave, filas, estado, extra=extra)
            if evidencia["registro_id"] not in archivados and _guardar(db, archivo, evidencia, aplicar):
                reporte["archivados_nuevos" if aplicar else "por_archivar"] += 1
            else:
                reporte["ya_archivados"] += 1
        reportes[nombre] = dict(reporte)
    return reportes
