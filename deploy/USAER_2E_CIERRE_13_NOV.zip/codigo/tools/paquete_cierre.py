"""Empaqueta solo el delta de código de la candidata y verifica su base instalada."""
import argparse
import difflib
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import zipfile

BASES = (
    "2d7774da0332c4588aa8ca94f4a4f052c0fa7635",
    "59e17e9efad645115f8d60ef190c466f2becf465",
    "b5d2e0d141974dace2d7b1dda89735214e8b023f",
    "1d6ff015c288f09d6c883b1217eb1b4595e86117",
    "f39ca186dc569a53cbf2f722db4bf222b99cee48",
    "88c4125c02b9d5124e815ee7bd4a6e5a88253398",
)
# Lista positiva: ningún archivo operativo, semilla, respaldo ni adaptador del host.
ARCHIVOS = frozenset((
    "data/sql_repository.py", "documents/epp.py",
    "piloto_spa/backend/archivo_historico.py", "piloto_spa/backend/auth_service.py",
    "piloto_spa/backend/conciliacion_archivo.py", "piloto_spa/backend/cronograma_borradores.py",
    "piloto_spa/backend/cronogramas_historicos.py",
    "piloto_spa/backend/horario_operativo.py",
    "piloto_spa/backend/domain_services.py", "piloto_spa/backend/epp_viva.py",
    "piloto_spa/backend/main.py", "piloto_spa/backend/static/index.html",
    "piloto_spa/backend/static/js/app.js", "piloto_spa/backend/static/js/epp-viva.js",
    "tests/navegador_recuperacion.cjs", "tests/navegador_recuperacion.py",
    "tests/test_spa_epp_viva.py", "tools/ampliar_recuperacion_historica.py",
    "tools/recuperacion_documental.py", "tools/paquete_cierre.py",
    "tools/captura_sheets_candidata.py", "tools/sincronizar_candidata.py",
    "tests/test_sincronizacion_candidata.py", "deploy/SINCRONIZACION_CANDIDATA.md",
    "deploy/CIERRE_UPPCODER.md",
))
MARCA = "USAER-CIERRE-1"
ADAPTADOR_SPARK = "ebc5922fda8aab8c350541429596d9ade3514276b6b4f32de75959788c6383a8"


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout


def digest(datos):
    return sha256(datos).hexdigest()


def blob(repo, revision, archivo):
    try:
        return git(repo, "show", f"{revision}:{archivo}")
    except subprocess.CalledProcessError:
        return None


def construir(repo, commit, salida):
    if not re.fullmatch(r"[0-9a-f]{40}", commit):
        raise ValueError("Indica el SHA completo de cierre.")
    nombres = set(git(repo, "diff", "--name-only", BASES[0], commit).decode().splitlines())
    if not nombres or not nombres <= ARCHIVOS:
        raise ValueError("El delta contiene rutas fuera de la lista de código revisada.")
    contenido = {}
    bases = {base: {} for base in BASES}
    for nombre in sorted(nombres):
        fichero = blob(repo, commit, nombre)
        if fichero is None or b"\x00" in fichero:
            raise ValueError("El paquete solo admite código y documentación en texto.")
        fichero.decode("utf-8")
        contenido[nombre] = digest(fichero)
        for base in BASES:
            anterior = blob(repo, base, nombre)
            bases[base][nombre] = digest(anterior) if anterior is not None else None
    manifiesto = {"formato": MARCA, "commit": commit, "bases": bases, "contenido": contenido}
    with zipfile.ZipFile(salida, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for nombre in sorted(nombres):
            z.writestr("codigo/" + nombre, blob(repo, commit, nombre))
        z.writestr("manifiesto.json", json.dumps(manifiesto, indent=2))
    return manifiesto


def leer_paquete(paquete):
    with zipfile.ZipFile(paquete) as z:
        miembros = z.namelist()
        if len(miembros) != len(set(miembros)) or "manifiesto.json" not in miembros:
            raise ValueError("Estructura de paquete inválida.")
        manifiesto = json.loads(z.read("manifiesto.json"))
        contenido = manifiesto["contenido"]
        if (manifiesto["formato"] != MARCA or not contenido or not contenido.keys() <= ARCHIVOS
                or not re.fullmatch(r"[0-9a-f]{40}", manifiesto["commit"])
                or set(manifiesto["bases"]) != set(BASES)
                or any(h.keys() != contenido.keys() for h in manifiesto["bases"].values())
                or set(miembros) != {"manifiesto.json", *("codigo/" + f for f in contenido)}):
            raise ValueError("Rutas o referencias inesperadas.")
        archivos = {nombre: z.read("codigo/" + nombre) for nombre in contenido}
        if any(digest(datos) != contenido[nombre] for nombre, datos in archivos.items()):
            raise ValueError("El paquete no pasó la verificación de integridad.")
    return manifiesto, archivos


def revisar_base(repo, manifiesto):
    repo = repo.resolve()
    observado = {}
    for nombre in manifiesto["contenido"]:
        p = repo
        for componente in PurePosixPath(nombre).parts:
            p = p / componente
            if p.is_symlink():
                raise ValueError("La instalación contiene un enlace en una ruta de actualización.")
        if p.exists() and not p.is_file():
            raise ValueError("Una ruta de actualización no es un archivo regular.")
        observado[nombre] = digest(p.read_bytes().replace(b"\r\n", b"\n")) if p.exists() else None
    return next((base for base, huellas in manifiesto["bases"].items() if observado == huellas), None)


def preparar(repo, paquete, salida):
    manifiesto, nuevos = leer_paquete(paquete)
    base = revisar_base(repo, manifiesto)
    if not base:
        raise ValueError("Base instalada distinta o archivos locales modificados. No se preparará el parche.")
    trozos = []
    for nombre, nuevo in sorted(nuevos.items()):
        previo = (repo / nombre).read_bytes().replace(b"\r\n", b"\n") if manifiesto["bases"][base][nombre] else b""
        if previo == nuevo:
            continue
        # Se preservan preimágenes para que la inversión sea exacta.
        entrada = "/dev/null" if not manifiesto["bases"][base][nombre] else "a/" + nombre
        diff = difflib.unified_diff(previo.decode("utf-8").splitlines(keepends=True),
                                    nuevo.decode("utf-8").splitlines(keepends=True),
                                    fromfile=entrada, tofile="b/" + nombre)
        for linea in diff:
            trozos.append(linea if linea.endswith("\n") else linea + "\n\\ No newline at end of file\n")
    datos = "".join(trozos).encode("utf-8")
    if not datos:
        raise ValueError("El paquete no contiene diferencias para la base observada.")
    prueba = subprocess.run(["git", "-C", str(repo), "apply", "--check", "--whitespace=nowarn", "-"],
                           input=datos, capture_output=True)
    if prueba.returncode:
        raise ValueError("Git no puede aplicar el parche de forma segura a esta instalación.")
    with salida.open("xb") as f:
        f.write(datos)
    return base


def verificar_adaptador(repo):
    raiz = Path.home().resolve() / "app"
    adaptador = raiz / "main.py"
    if (repo.resolve() != raiz / "usaer2e" or adaptador.is_symlink() or not adaptador.is_file()
            or digest(adaptador.read_bytes()) != ADAPTADOR_SPARK
            or not (repo / "deploy/uppcoder.py").is_file()):
        raise ValueError("Adaptador Uppcoder distinto del comprobado; se conserva sin cambios.")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("accion", choices=("crear", "verificar", "preparar"))
    p.add_argument("--repo", required=True, type=Path)
    p.add_argument("--paquete", required=True, type=Path)
    p.add_argument("--commit")
    p.add_argument("--parche", type=Path)
    p.add_argument("--uppcoder", action="store_true")
    args = p.parse_args()
    try:
        if args.uppcoder:
            verificar_adaptador(args.repo)
        if args.accion == "crear":
            r = construir(args.repo, args.commit or "", args.paquete)
            leer_paquete(args.paquete)
            print(f"Paquete verificado: {r['commit']}; {len(r['contenido'])} archivos de código y pruebas.")
        elif args.accion == "preparar":
            if not args.parche:
                raise ValueError("Indica el destino privado para el parche reversible.")
            base = preparar(args.repo, args.paquete, args.parche)
            print(f"Parche reversible preparado para {base}. No se cambió el clon.")
        else:
            m, _ = leer_paquete(args.paquete)
            base = revisar_base(args.repo, m)
            if not base:
                raise ValueError("Base instalada distinta o archivos locales modificados. No se aplicará el paquete.")
            print(f"Integridad confirmada; base exacta {base}, candidata {m['commit']}. Sin cambios aplicados.")
    except (ValueError, OSError, subprocess.CalledProcessError, zipfile.BadZipFile, KeyError) as exc:
        raise SystemExit(str(exc) if isinstance(exc, ValueError) else "No se pudo verificar el paquete.") from None


if __name__ == "__main__":
    main()
