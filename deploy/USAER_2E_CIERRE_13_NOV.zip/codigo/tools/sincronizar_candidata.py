"""Cortes incrementales de Sheets a la candidata PostgreSQL, sin escribir en el origen."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
from uuid import uuid4

from sqlalchemy import select, text, update
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from data.database import Alumno, ColeccionInstitucional, EPPDoc, Escuela, PlaneacionDoc, Usuario
from tools.ampliar_recuperacion_historica import ANEXOS, ARCHIVO, _anexo, _registro_archivo, ampliar
from tools.captura_sheets_candidata import IDENTIDADES, capturas_xlsx, desde_google
from tools.recuperacion_documental import (
    Documento, Incompatible, _huella, _serializar, conciliar, destino_candidato,
    reconstruir_epp, reconstruir_planeacion,
)

ESTADO = "sync_fuente_estado"
CORTES = "sync_fuente_cortes"
CONFLICTOS = "sync_fuente_conflictos"
REVISIONES = "sync_fuente_revisiones"
TABLA = ColeccionInstitucional.__table__
ESTADOS_MUTABLES = {"ACTIVO", "ACTIVA", "BORRADOR", "RETIRADO", "RETIRADA", "ANULADO", "ANULADA"}
CAMPOS_INMUTABLES = {"id", "id_alumno", "id_escuela", "escuela", "id_personal", "docente_especialista",
                     "especialista", "elaborado_por", "fecha", "fecha_elaboracion", "fecha_nacimiento"}
DIR_CANDIDATA = Path("V:/USAER-Candidata-Historica-2/pgdata")


def _escribir(db, modulo, rid, contenido, *, fuente="", fecha="", sustituir=False):
    valores = {"id": f"{modulo}:{rid}", "modulo": modulo, "registro_id": rid,
               "cuenta": fuente, "fecha": fecha, "payload_json": _serializar(contenido)}
    sql = insert(TABLA).values(**valores)
    if sustituir:
        sql = sql.on_conflict_do_update(index_elements=[TABLA.c.id], set_={
            "fecha": sql.excluded.fecha, "payload_json": sql.excluded.payload_json,
        })
    else:
        sql = sql.on_conflict_do_nothing(index_elements=[TABLA.c.id])
    return db.execute(sql.returning(TABLA.c.id)).scalar_one_or_none() is not None


def _incidencia(db, fuente, nombre, rid, previo, origen, operativo, motivo, fecha):
    llave = _huella([fuente, nombre, rid, origen, _huella(operativo), motivo])
    evidencia = {"pestana": nombre, "origen": origen, "motivo": motivo,
                 "referencia_anterior": previo.get("origen"), "postgresql": operativo}
    return _escribir(db, CONFLICTOS, llave, evidencia, fuente=fuente, fecha=fecha)


def _valor_db(db, modelo, valores, aplicar):
    sql = select(modelo).where(modelo.id == valores["id"])
    if aplicar:
        sql = sql.with_for_update()
    objeto = db.scalar(sql)
    return ({k: getattr(objeto, k) or "" for k in valores} if objeto is not None else None)


def _anexos(db, nombre, clave, filas, padron, escuelas, previo, aplicar):
    if not clave[0] or any(r != filas[0] for r in filas[1:]):
        return "identidad_ambigua", None, None
    try:
        tabla, nuevos = _anexo(nombre, filas[0], padron, escuelas)
    except Incompatible as exc:
        return str(exc), None, None
    modelo = ANEXOS[nombre][0]
    actual = _valor_db(db, modelo, nuevos, aplicar)
    estado_nuevo = nuevos.get("estado", "").upper()
    if actual is None:
        if "estado" in nuevos and estado_nuevo not in ESTADOS_MUTABLES:
            return "estado_protegido_o_desconocido", None, None
        if aplicar:
            sql = insert(tabla).values(**nuevos).on_conflict_do_nothing(index_elements=[tabla.c.id])
            if db.execute(sql).rowcount != 1:
                raise Incompatible("registro_operativo_cambio_durante_el_corte")
        return "alta_operativa", _huella(nuevos), None
    huella_actual = _huella(actual)
    if actual == nuevos:
        return "coincidencia_operativa", huella_actual, None
    if previo.get("operativa") != huella_actual:
        causa = "edicion_en_ambos_origenes" if previo.get("operativa") else "sin_ancestro_operativo_verificado"
        return causa, None, actual
    if any(actual[k] != nuevos[k] for k in nuevos.keys() & CAMPOS_INMUTABLES):
        return "identidad_autoria_o_fecha_protegida", None, actual
    if "estado" in nuevos and (estado_nuevo not in ESTADOS_MUTABLES or actual["estado"].upper() not in ESTADOS_MUTABLES):
        return "estado_protegido_o_desconocido", None, actual
    if aplicar:
        revision_id = _huella([tabla.name, nuevos["id"], actual])
        _escribir(db, REVISIONES, revision_id, {"tabla": tabla.name, "datos": actual})
        db.execute(update(tabla).where(tabla.c.id == nuevos["id"]).values(
            **{k: v for k, v in nuevos.items() if actual[k] != v}))
    return "actualizacion_operativa", _huella(nuevos), None


def _diario(db, nombre, filas, padron, autores, aplicar):
    es_plan = nombre == "Planeaciones_Versiones"
    try:
        versiones = reconstruir_planeacion(filas) if es_plan else reconstruir_epp(filas)
    except Incompatible as exc:
        return str(exc), None, None
    doc = Documento("planeaciones" if es_plan else "epp", versiones)
    vigente = doc.vigente
    if es_plan:
        oper = db.get(PlaneacionDoc, vigente["id"])
        existente = json.loads(oper.payload_json or "{}") if oper else None
        exacto = vigente
    else:
        ids = (vigente["alumno"], "epp-" + vigente["alumno"], "alu-uppcoder-" + vigente["alumno"])
        ops = db.scalars(select(EPPDoc).where(EPPDoc.alumno.in_(ids), EPPDoc.ciclo == vigente["ciclo"])).all()
        if len(ops) > 1:
            return "multiples_epp_operativas", None, [{"revision": r.revision,
                    "partes": json.loads(r.partes_json or "{}")} for r in ops]
        oper = ops[0] if ops else None
        existente = json.loads(oper.partes_json or "{}") if oper else None
        exacto = vigente["partes"]
    if oper:
        if oper.revision == vigente["revision"] and existente == exacto:
            return "coincidencia_operativa", _huella(existente), None
        return "rama_documental_requiere_conciliacion", None, {"revision": oper.revision, "contenido": existente}
    for version, meta in versiones:
        escuela = version["datos"]["ID_Escuela"] if es_plan else padron.get(version["alumno"])
        if not escuela or escuela not in autores.get(meta["cuenta"], set()) and "TODAS" not in autores.get(meta["cuenta"], set()):
            return "autoria_o_escuela_no_conciliada", None, None
    estado = vigente["estado"] if es_plan else vigente["partes"]["META"]["estado"]
    if str(estado).upper() not in ESTADOS_MUTABLES:
        return "vigencia_o_firma_requiere_conciliacion", None, None
    if not es_plan:
        conclusion = vigente["partes"].get("Conclusión", {}).get("contenido", {})
        if conclusion.get("validada") or conclusion.get("nee"):
            return "conclusion_o_nee_requiere_conciliacion", None, None
    reporte = conciliar(db.connection(), [doc], aplicar=aplicar, administrar_transaccion=False)[doc.tipo]
    if not reporte.get("conciliados"):
        return next((k for k in ("autor_no_conciliado", "matricula_no_conciliada") if reporte.get(k)),
                    "diario_no_conciliado"), None, None
    return "alta_operativa", _huella(exacto), None


def sincronizar(db, capturas, *, aplicar=False, solo_referencia=False, referencias=()):
    """Se ejecuta en una única transacción; un manifiesto idéntico no escribe nada."""
    if aplicar:
        db.execute(text("SELECT pg_advisory_xact_lock(254811623)"))
    padron = {a.id: a for a in db.scalars(select(Alumno))}
    escuelas = dict(db.execute(select(Escuela.id, Escuela.nombre_escuela)).all())
    autores = {}
    for usuario, rol, permitidas in db.execute(select(Usuario.usuario, Usuario.rol, Usuario.escuelas_permitidas)):
        autores[usuario] = {"TODAS"} if "DIRECTOR" in (rol or "").upper() else {
            e.strip() for e in (permitidas or "").split(",") if e.strip()
        }
    resultado = []
    por_fuente = {r.fuente: r for r in referencias}
    for captura in capturas:
        fuente = captura.modo + ":" + captura.fuente + (":referencia" if solo_referencia else "")
        cabeza = _huella([fuente, "cabeza"])
        previos = {k: json.loads(v) for k, v in db.execute(select(TABLA.c.registro_id, TABLA.c.payload_json).where(
            TABLA.c.modulo == ESTADO, TABLA.c.cuenta == fuente))}
        anterior = previos.pop(cabeza, {})
        if captura.fuente in por_fuente:
            base = por_fuente[captura.fuente]
            etiqueta = f"xlsx:{base.fuente}:referencia"
            refs = {k: json.loads(v) for k, v in db.execute(select(TABLA.c.registro_id, TABLA.c.payload_json)
                    .where(TABLA.c.modulo == ESTADO, TABLA.c.cuenta == etiqueta))}
            corte_base = refs.pop(_huella([etiqueta, "cabeza"]), {})
            if corte_base.get("huella") != base.huella:
                raise Incompatible("referencia_no_coincide_con_corte_archivado")
            estados_base = {}
            for nombre, grupos in base.hojas.items():
                for clave, filas in grupos.items():
                    referencia = refs.get(_huella([etiqueta, nombre, clave]))
                    if not referencia or referencia.get("huella") != _huella(filas):
                        raise Incompatible("referencia_individual_no_verificada")
                    rid = _huella([fuente, nombre, clave])
                    if rid in previos:
                        continue
                    evidencia = dict(referencia)
                    # Solo una coincidencia exacta acredita un ancestro compartido;
                    # la semejanza de nombre o una revisión distinta no bastan.
                    if nombre in ANEXOS and clave[0] and all(f == filas[0] for f in filas):
                        try:
                            _, valores = _anexo(nombre, filas[0], padron, escuelas)
                            actual = _valor_db(db, ANEXOS[nombre][0], valores, False)
                            if actual == valores:
                                evidencia["operativa"] = _huella(valores)
                        except Incompatible:
                            pass
                    estados_base[rid] = evidencia
            previos = {**estados_base, **previos}
        stats, cambios = {}, {}
        registros_presentes = set()
        for nombre, grupos in captura.hojas.items():
            cuenta = Counter(en_origen=sum(map(len, grupos.values())), identidades=len(grupos))
            stats[nombre] = cuenta
            for clave, filas in grupos.items():
                rid = _huella([fuente, nombre, clave])
                registros_presentes.add(rid)
                huella = _huella(filas)
                previo = previos.get(rid, {})
                if previo.get("huella") == huella:
                    cuenta["sin_cambio"] += 1
                    continue
                cuenta["modificados_en_origen" if previo else "nuevos_en_cotejo"] += 1
                cambios.setdefault(nombre, {})[clave] = (rid, huella, previo, filas)
        ausentes = len(set(previos) - registros_presentes)
        if not cambios and anterior.get("huella") == captura.huella:
            resultado.append({"fuente": fuente, "corte": anterior, "escrituras": 0,
                              "ausentes_no_borrados": ausentes, "tipos": stats})
            continue
        escrituras = 0
        # Primero preserva originales y prueba vínculos de adjuntos y de línea de tiempo.
        # Excluye anexos y diarios de la proyección previa para aplicar el cotejo de tres vías.
        extras = {n: {k: x[-1] for k, x in grupo.items()} for n, grupo in cambios.items()
                  if n not in ANEXOS and n not in {"Planeaciones_Versiones", "EPP_Versiones"}}
        for dependencia in ("Expedientes", "Archivos_Expediente"):
            if dependencia in captura.hojas:
                extras[dependencia] = captura.hojas[dependencia]
        if extras and not solo_referencia:
            detalle = ampliar(db, aplicar=aplicar, capturados=extras)
            for nombre, conteo in detalle.items():
                if nombre in stats:
                    stats[nombre].update({k: v for k, v in conteo.items()
                                          if k not in {"filas_fuente", "grupos_fuente"}})
                if aplicar:
                    escrituras += conteo.get("archivados_nuevos", 0) + conteo.get("incorporado", 0)
        for nombre, grupos in cambios.items():
            for clave, (rid, huella, previo, filas) in grupos.items():
                archivable = nombre in ANEXOS or nombre in {"Planeaciones_Versiones", "EPP_Versiones"}
                if solo_referencia:
                    estado, operativa, local = "referencia_sin_proyeccion", None, None
                elif nombre in ANEXOS:
                    estado, operativa, local = _anexos(db, nombre, clave, filas, padron, escuelas, previo, aplicar)
                elif nombre in {"Planeaciones_Versiones", "EPP_Versiones"}:
                    estado, operativa, local = _diario(db, nombre, filas,
                                                      {k: a.id_escuela for k, a in padron.items()}, autores, aplicar)
                else:
                    estado = "identidad_o_permiso_requiere_revision" if nombre in IDENTIDADES else "archivado_para_revision"
                    operativa, local = None, None
                stats[nombre][estado] += 1
                fila = _registro_archivo(nombre, clave, filas, estado)
                ref = fila["registro_id"].split(":", 1)[1]
                if aplicar:
                    if archivable or solo_referencia:
                        escrituras += db.execute(insert(TABLA).values(**fila).on_conflict_do_nothing(
                            index_elements=[TABLA.c.id])).rowcount
                    if local is not None:
                        escrituras += int(_incidencia(db, fuente, nombre, rid, previo, ref, local, estado, captura.fecha))
                    escrituras += int(_escribir(db, ESTADO, rid, {"huella": huella, "origen": ref,
                        "operativa": operativa, "estado": estado}, fuente=fuente, fecha=captura.fecha, sustituir=True))
                    escrituras += int(estado in {"alta_operativa", "actualizacion_operativa"})
        corte = {"huella": captura.huella, "observado_en": captura.fecha, "modo": captura.modo,
                 "solo_referencia": solo_referencia,
                 "pestañas_ausentes": captura.ausentes, "anterior": anterior.get("id")}
        corte["id"] = _huella([fuente, corte["huella"], corte["anterior"]])
        if aplicar:
            _escribir(db, CORTES, corte["id"], {**corte, "tipos": stats, "ausentes_no_borrados": ausentes},
                      fuente=fuente, fecha=captura.fecha)
            _escribir(db, ESTADO, cabeza, corte, fuente=fuente, fecha=captura.fecha, sustituir=True)
            escrituras += 2
        resultado.append({"fuente": fuente, "corte": corte, "escrituras": escrituras,
                          "ausentes_no_borrados": ausentes, "tipos": stats})
    return resultado


def _respaldo(url, carpeta, pg_dump, pg_restore):
    if (os.name != "nt" or not carpeta.is_dir() or carpeta.resolve().drive.upper() != "V:"
            or not pg_dump.is_file() or not pg_restore.is_file()):
        raise Incompatible("respaldo_requiere_clientes_postgresql_y_volumen_cifrado")
    archivo = carpeta / f"antes-sync-{uuid4().hex}.dump"
    env = dict(os.environ, PGPASSWORD=url.password or os.environ.get("PGPASSWORD", ""))
    backup = subprocess.run([str(pg_dump), "-w", "-h", url.host, "-p", str(url.port), "-U", url.username,
                             "-Fc", "-f", str(archivo), url.database], env=env, capture_output=True, timeout=180)
    if backup.returncode or not archivo.is_file() or archivo.stat().st_size == 0:
        raise Incompatible("respaldo_no_confirmado")
    indice = subprocess.run([str(pg_restore), "-l", str(archivo)], capture_output=True, timeout=60)
    if indice.returncode or b"colecciones_institucionales" not in indice.stdout:
        raise Incompatible("respaldo_no_legible")


def main():
    from sqlalchemy import create_engine
    from config.settings import URL_SPREADSHEET_MAESTRO, CRONOGRAMAS_SPREADSHEET_ID

    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--maestro-xlsx", type=Path)
    p.add_argument("--referencia-maestro-xlsx", type=Path,
                   help="Archivo original del corte de referencia ya registrado.")
    p.add_argument("--cronogramas-xlsx", type=Path)
    p.add_argument("--credencial-lectura", type=Path)
    p.add_argument("--aplicar", action="store_true")
    p.add_argument("--solo-referencia", action="store_true", help="Registra XLSX fijo sin proyectar ni editar documentos operativos.")
    p.add_argument("--respaldo-dir", type=Path)
    p.add_argument("--pg-dump", type=Path)
    p.add_argument("--pg-restore", type=Path)
    args = p.parse_args()
    try:
        archivos = {k: v for k, v in {"maestro": args.maestro_xlsx, "cronogramas": args.cronogramas_xlsx}.items() if v}
        if bool(archivos) == bool(args.credencial_lectura):
            raise Incompatible("elige_xlsx_o_credencial_lectura")
        if args.solo_referencia and not archivos:
            raise Incompatible("solo_referencia_requiere_una_copia_fija")
        if args.referencia_maestro_xlsx and (not args.maestro_xlsx or args.solo_referencia):
            raise Incompatible("referencia_requiere_un_nuevo_xlsx_maestro")
        url = destino_candidato(os.environ.get("USAER_HISTORICA_DSN", ""))
        motor = create_engine(url, hide_parameters=True, isolation_level="SERIALIZABLE")
        with motor.connect() as db:
            if Path(db.execute(text("SHOW data_directory")).scalar_one()) != DIR_CANDIDATA:
                raise Incompatible("destino_no_es_la_candidata_cifrada")
        if args.credencial_lectura:
            capturas = desde_google(args.credencial_lectura,
                {"maestro": URL_SPREADSHEET_MAESTRO.rstrip("/").split("/")[-1], "cronogramas": CRONOGRAMAS_SPREADSHEET_ID})
        else:
            capturas = capturas_xlsx(archivos)
        referencias = capturas_xlsx({"maestro": args.referencia_maestro_xlsx}) if args.referencia_maestro_xlsx else ()
        if args.aplicar:
            # Una repetición verificada no genera otro volcado ni escribe un corte.
            with Session(motor) as db, db.begin():
                db.execute(text("SET TRANSACTION READ ONLY"))
                iguales = True
                for captura in capturas:
                    fuente = captura.modo + ":" + captura.fuente + (":referencia" if args.solo_referencia else "")
                    marca = db.get(ColeccionInstitucional, f"{ESTADO}:{_huella([fuente, 'cabeza'])}")
                    if not marca or json.loads(marca.payload_json).get("huella") != captura.huella:
                        iguales = False
                        break
                if iguales:
                    resultado = sincronizar(db, capturas, solo_referencia=args.solo_referencia,
                                             referencias=referencias)
                    print(_serializar({"aplicado": True, "repeticion_verificada": True, "cortes": resultado}))
                    return
        if args.aplicar:
            if not all((args.respaldo_dir, args.pg_dump, args.pg_restore)):
                raise Incompatible("indica_respaldo_y_clientes_postgresql")
            _respaldo(url, args.respaldo_dir, args.pg_dump, args.pg_restore)
        with Session(motor) as db, db.begin():
            if not args.aplicar:
                db.execute(text("SET TRANSACTION READ ONLY"))
            resultado = sincronizar(db, capturas, aplicar=args.aplicar, solo_referencia=args.solo_referencia,
                                   referencias=referencias)
        print(_serializar({"aplicado": args.aplicar, "cortes": resultado}))
    except Incompatible as exc:
        raise SystemExit(f"Sincronización detenida: {exc}") from None
    except Exception as exc:
        # La excepción de una biblioteca puede incluir credenciales, filas o parámetros SQL.
        raise SystemExit(f"Sincronización detenida ({type(exc).__name__}); no se muestran datos privados.") from None


if __name__ == "__main__":
    main()
