"""Recuperación de borradores de cronograma, separada de la publicación mensual."""
from datetime import date, datetime, timezone
from hashlib import sha256
import json
import re
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import cast, select, text
from sqlalchemy.dialects.postgresql import JSONB

from data.database import ColeccionInstitucional as Registro, get_session
from tools.ampliar_recuperacion_historica import ARCHIVO
from tools.recuperacion_documental import _huella
from utils.text import normalizar_texto

MODULO = "cronogramas_borrador_vivo"
FUENTE = "Borradores_Cronogramas"


def _perfil(user):
    from services.cronogramas import perfil_especialista
    if not user.director and user.area not in {"Psicología", "Comunicación", "Trabajo Social"}:
        raise HTTPException(403, "Esta cuenta no tiene cronograma propio autorizado.")
    perfil = perfil_especialista(user.nombre, user.rol)
    if not perfil or perfil["area"] not in {"Psicología", "Comunicación", "Trabajo Social", "Dirección"}:
        raise HTTPException(403, "Esta cuenta no tiene cronograma propio autorizado.")
    return perfil


def _mes(mes):
    if not re.fullmatch(r"20\d{2}-(?:0[1-9]|1[0-2])", mes):
        raise HTTPException(422, "Indica el mes en formato AAAA-MM.")
    return mes


def _agenda(raw, mes, perfil):
    from services.cronogramas import lugares_cronograma
    if not isinstance(raw, dict) or len(raw) > 31:
        raise ValueError("Agenda inválida.")
    sedes = {normalizar_texto(s) for s in [*perfil["escuelas"], *lugares_cronograma(perfil)]}
    for dia, ficha in raw.items():
        if (not isinstance(dia, str) or not dia.startswith(mes + "-")
                or date.fromisoformat(dia).isoformat() != dia or not isinstance(ficha, dict)):
            raise ValueError("Fecha o actividad inválida.")
        escuela = ficha.get("escuela", "")
        if not isinstance(escuela, str) or (escuela and normalizar_texto(escuela) not in sedes):
            raise ValueError("El borrador contiene una sede no autorizada.")
        if not isinstance(ficha.get("actividad", ""), str):
            raise ValueError("Actividad inválida.")
    if len(json.dumps(raw, ensure_ascii=False)) > 45000:
        raise ValueError("El borrador supera el límite de contenido.")
    return raw


def _fuente(db, perfil, mes, ref=None):
    payload = cast(Registro.payload_json, JSONB)
    consulta = select(Registro).where(
        Registro.modulo == ARCHIVO, Registro.registro_id.startswith(FUENTE + ":", autoescape=True),
        payload["clave"][2].astext == mes,
    )
    if perfil:
        consulta = consulta.where(payload["clave"][1].astext == perfil["nombre"])
    if ref:
        consulta = consulta.where(Registro.registro_id == FUENTE + ":" + ref)
    return db.scalars(consulta.order_by(Registro.fecha.desc(), Registro.id))


def _historico(registro, perfil, mes):
    evidencia = json.loads(registro.payload_json)
    original = evidencia["filas"]
    ref = registro.registro_id.split(":", 1)[1]
    if ref != _huella([FUENTE, evidencia["clave"], original]):
        return None
    if not original or any(f != original[0] for f in original[1:]):
        return None
    fila = original[0]
    try:
        if fila["ID_Version"] != evidencia["clave"][0]:
            return None
        momento = datetime.fromisoformat(fila["Guardado_En"])
        if momento.utcoffset() is None:
            return None
        dias = _agenda(json.loads(fila["Dias_JSON"]), mes, perfil)
    except (KeyError, TypeError, ValueError):
        return None
    return {"ref": ref, "version_origen": fila["ID_Version"],
            "fecha": fila["Guardado_En"], "dias": dias, "estado": "BORRADOR_HISTORICO"}


def _versiones(db, user, mes, limite=50):
    return db.scalars(select(Registro).where(
        Registro.modulo == MODULO, Registro.cuenta == user.usuario, Registro.id_escuela == mes,
    ).order_by(Registro.fecha.desc(), Registro.id).limit(limite))


def consultar(user, mes):
    from services.cronogramas import lugares_cronograma
    perfil = _perfil(user)
    mes = _mes(mes)
    with get_session(initialize_schema=False) as db:
        recuperables = [h for r in _fuente(db, perfil, mes) if (h := _historico(r, perfil, mes))]
        propias = [json.loads(r.payload_json) for r in _versiones(db, user, mes)]
    return {"mes": mes, "actual": propias[0] if propias else None,
            "sedes": [*perfil["escuelas"], *lugares_cronograma(perfil)],
            "versiones": [{k: h[k] for k in ("revision", "fecha", "origen")} for h in propias],
            "historicos": [{k: h[k] for k in ("ref", "version_origen", "fecha", "estado")} for h in recuperables]}


def abrir(user, mes, ref):
    perfil = _perfil(user)
    mes = _mes(mes)
    with get_session(initialize_schema=False) as db:
        if re.fullmatch(r"[a-f0-9]{64}", ref):
            for r in _fuente(db, perfil, mes, ref):
                if dato := _historico(r, perfil, mes):
                    return dato
        if re.fullmatch(r"[a-f0-9]{32}", ref):
            r = db.get(Registro, f"{MODULO}:{ref}")
            if r and r.modulo == MODULO and r.cuenta == user.usuario and r.id_escuela == mes:
                return json.loads(r.payload_json)
    raise HTTPException(404, "Borrador no disponible.")


def _perfil_archivo(nombre):
    from services.cronogramas import perfil_especialista
    for rol in ("DIRECTOR", "PSICOLOGIA", "COMUNICACION", "TRABAJO SOCIAL"):
        perfil = perfil_especialista(nombre, rol)
        if perfil and perfil["nombre"] == nombre:
            return perfil
    return None


def supervisar(user, mes, ref=None):
    if not user.director:
        raise HTTPException(403, "Supervisión reservada a Dirección.")
    mes = _mes(mes)
    if ref and not re.fullmatch(r"[a-f0-9]{64}", ref):
        raise HTTPException(404, "Borrador no disponible.")
    datos = []
    with get_session(initialize_schema=False) as db:
        for r in _fuente(db, None, mes, ref):
            clave = json.loads(r.payload_json)["clave"]
            if perfil := _perfil_archivo(clave[1]):
                if original := _historico(r, perfil, mes):
                    if ref:
                        return original, perfil
                    datos.append({**{k: original[k] for k in ("ref", "fecha", "estado")},
                                  "especialista": perfil["nombre"], "area": perfil["area"],
                                  "dias": len(original["dias"])})
    if ref:
        raise HTTPException(404, "Borrador no disponible.")
    return datos


def guardar(user, mes, revision, origen, dias):
    perfil = _perfil(user)
    mes = _mes(mes)
    try:
        _agenda(dias, mes, perfil)
    except (ValueError, TypeError):
        raise HTTPException(422, "Verifica las fechas, sedes y contenido del borrador.") from None
    with get_session(initialize_schema=False) as db:
        candado = int.from_bytes(sha256(f"{MODULO}:{user.usuario}:{mes}".encode()).digest()[:8], "big", signed=True)
        db.execute(text("SELECT pg_advisory_xact_lock(:clave)"), {"clave": candado})
        actual = next(iter(_versiones(db, user, mes, 1)), None)
        previa = json.loads(actual.payload_json) if actual else {}
        if previa.get("revision") != revision:
            raise HTTPException(409, "El borrador cambió en otra sesión. Conserva tus cambios y vuelve a abrirlo.")
        if origen:
            if not re.fullmatch(r"[a-f0-9]{64}", origen) or not any(
                _historico(r, perfil, mes) for r in _fuente(db, perfil, mes, origen)
            ):
                raise HTTPException(404, "Origen no disponible.")
        revision = uuid4().hex
        fecha = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        doc = {"revision": revision, "anterior": previa.get("revision"), "origen": origen or previa.get("origen"),
               "fecha": fecha, "dias": dias, "estado": "BORRADOR"}
        db.add(Registro(id=f"{MODULO}:{revision}", modulo=MODULO, registro_id=revision,
                        cuenta=user.usuario, id_escuela=mes, fecha=fecha, estado="BORRADOR",
                        payload_json=json.dumps(doc, ensure_ascii=False)))
        db.commit()
        return doc
