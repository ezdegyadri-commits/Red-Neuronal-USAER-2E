"""Lectura de la recuperación histórica, separada de los documentos vigentes."""
import json
import re

from fastapi import HTTPException, Response
from sqlalchemy import select

from data.database import ColeccionInstitucional as Registro, get_session
from tools.ampliar_recuperacion_historica import ARCHIVO, CRONOGRAMAS_PUBLICADOS, validar_adjunto
from tools.recuperacion_documental import Incompatible, LIBRO_MAESTRO


def fuentes():
    from tools.captura_sheets_candidata import IDENTIDADES
    return list(dict.fromkeys((*LIBRO_MAESTRO, CRONOGRAMAS_PUBLICADOS, *IDENTIDADES)))


def indice(pestana, offset, limite):
    if pestana not in fuentes():
        raise HTTPException(404, "Fuente no disponible.")
    with get_session(initialize_schema=False) as db:
        filas = db.execute(select(Registro.registro_id, Registro.estado, Registro.fecha).where(
            Registro.modulo == ARCHIVO, Registro.registro_id.startswith(pestana + ":", autoescape=True),
        ).order_by(Registro.registro_id).offset(offset).limit(limite + 1)).all()
    return {"filas": [{"ref": r.registro_id.split(":", 1)[1], "estado": r.estado, "fecha": r.fecha}
                      for r in filas[:limite]],
            "siguiente": offset + limite if len(filas) > limite else None}


def detalle(ref):
    if not re.fullmatch(r"[a-f0-9]{64}", ref):
        raise HTTPException(404, "Registro no disponible.")
    with get_session(initialize_schema=False) as db:
        registro = db.get(Registro, f"{ARCHIVO}:{ref}")
        if registro is None or registro.modulo != ARCHIVO:
            raise HTTPException(404, "Registro no disponible.")
        return Response(registro.payload_json, media_type="application/json",
                        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


def _adjuntos(db, alumno, autorizados):
    registros = db.scalars(select(Registro).where(
        Registro.modulo == ARCHIVO, Registro.estado == "adjunto_con_binario_verificado",
        Registro.registro_id.startswith("Documentos_Expediente:", autoescape=True),
    ))
    for registro in registros:
        payload = json.loads(registro.payload_json)
        ficha = payload["filas"][0]
        try:
            ids = json.loads(ficha["ID_Alumnos_JSON"])
        except (ValueError, KeyError):
            continue
        if (not isinstance(ids, list) or not ids or not all(isinstance(i, str) for i in ids) or
                alumno not in ids or ficha.get("Estado") != "VIGENTE" or not ficha.get("ID_Escuela") or
                any(autorizados.get(a) != ficha["ID_Escuela"] for a in ids)):
            continue
        yield registro.registro_id.split(":", 1)[1], ficha, payload["fragmentos_ref"]


def adjuntos(alumno, autorizados):
    with get_session(initialize_schema=False) as db:
        return [{"ref": ref, "nombre": ficha["Nombre"], "tipo": ficha["Tipo"], "fecha": ficha["Fecha"],
                 "extension": {"application/pdf": ".pdf", "image/jpeg": ".jpg", "image/png": ".png"}.get(
                     ficha.get("Mime"), ".bin")}
                for ref, ficha, _ in _adjuntos(db, alumno, autorizados)]


def descargar(alumno, autorizados, ref):
    with get_session(initialize_schema=False) as db:
        coincidencias = [(ficha, fragmentos) for key, ficha, fragmentos in _adjuntos(db, alumno, autorizados)
                         if key == ref]
        if len(coincidencias) == 1:
            ficha, fragmentos = coincidencias[0]
            registro = db.get(Registro, fragmentos)
            if registro and registro.modulo == ARCHIVO:
                try:
                    data = validar_adjunto(ficha, json.loads(registro.payload_json)["filas"])
                except Incompatible:
                    raise HTTPException(409, "El adjunto no supera la comprobación de integridad.") from None
                extension = {"application/pdf": ".pdf", "image/jpeg": ".jpg", "image/png": ".png"}.get(
                    ficha.get("Mime"), ".bin")
                return Response(data, media_type="application/octet-stream", headers={
                    "Content-Disposition": f'attachment; filename="Adjunto-historico{extension}"',
                    "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff",
                })
    raise HTTPException(404, "Adjunto no disponible.")
