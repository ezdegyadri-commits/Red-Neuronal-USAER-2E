"""Consulta de versiones históricas del libro de cronogramas; nunca publica."""
import json
import re

from fastapi import HTTPException
from sqlalchemy import select

from config.settings import ESCUELAS_USAER
from data.database import ColeccionInstitucional as Registro, get_session
from piloto_spa.backend.cronograma_borradores import _mes, _perfil
from services.cronogramas import _iso_fecha, lugares_cronograma
from tools.ampliar_recuperacion_historica import ARCHIVO, CRONOGRAMAS_PUBLICADOS as FUENTE
from tools.recuperacion_documental import _huella
from utils.text import normalizar_texto


def _alcance(user):
    if user.director:
        return None, set()
    perfil = _perfil(user)
    permitidas = {normalizar_texto(k) for k in user.escuelas_permitidas}
    escuelas = {normalizar_texto(n) for n in perfil["escuelas"] if
                "TODAS" in permitidas or normalizar_texto(n) in permitidas or
                normalizar_texto(ESCUELAS_USAER.get(n, "")) in permitidas}
    return perfil["nombre"], escuelas | {normalizar_texto(n) for n in lugares_cronograma(perfil)}


def consultar(user, mes, ref=None):
    mes = _mes(mes)
    cuenta, escuelas = _alcance(user)
    if ref is not None and not re.fullmatch(r"[a-f0-9]{64}", ref):
        raise HTTPException(404, "Cronograma histórico no disponible.")
    with get_session(initialize_schema=False) as db:
        consulta = select(Registro.registro_id, Registro.payload_json).where(
            Registro.modulo == ARCHIVO, Registro.registro_id.startswith(FUENTE + ":", autoescape=True))
        if ref is not None:
            consulta = consulta.where(Registro.registro_id == FUENTE + ":" + ref)
        salida = []
        for rid, bruto in db.execute(consulta.order_by(Registro.registro_id)):
            fuente = json.loads(bruto)
            clave, filas = fuente["clave"], fuente["filas"]
            origen = rid.split(":", 1)[1]
            if origen != _huella([FUENTE, clave, filas]):
                continue
            if cuenta and (len(clave) != 2 or not clave[0] or clave[1] != cuenta or
                           any(f.get("Especialista") != cuenta or normalizar_texto(f.get("Escuela", "")) not in escuelas
                               for f in filas)):
                continue
            actividades = []
            for f in filas:
                fecha = _iso_fecha(f.get("Fecha"))
                if fecha.startswith(mes + "-"):
                    actividades.append({"fecha": fecha, "escuela": f.get("Escuela", ""),
                        "actividad": f.get("Actividad", ""), "estado_origen": f.get("Estado", "")})
            if not actividades:
                continue
            doc = {"ref": origen, "publicacion": filas[0].get("ID_Publicacion", ""),
                   "especialista": filas[0].get("Especialista", ""),
                   "revision_origen": filas[0].get("Marca temporal", ""),
                   "cantidad": len(actividades), "vigencia_confirmada": False}
            if ref is not None:
                return {**doc, "actividades": actividades}
            salida.append(doc)
    if ref is not None:
        raise HTTPException(404, "Cronograma histórico no disponible.")
    return salida
