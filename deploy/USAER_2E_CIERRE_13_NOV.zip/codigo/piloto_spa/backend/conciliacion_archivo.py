"""Conciliación explícita: compare y registre una decisión sin mutar originales."""
from collections import defaultdict
from datetime import datetime, timezone
import json
import re
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import select

from data.database import ColeccionInstitucional as Registro, EPPDoc, PlaneacionDoc, get_session
from tools.ampliar_recuperacion_historica import ARCHIVO
from tools.recuperacion_documental import Incompatible, _huella, reconstruir_epp, reconstruir_planeacion

MODULO = "decisiones_archivo_historico"


def _archivo(db, ref):
    if not re.fullmatch(r"[a-f0-9]{64}", ref):
        raise HTTPException(404, "Origen no disponible.")
    r = db.get(Registro, f"{ARCHIVO}:{ref}")
    if r is None or r.modulo != ARCHIVO:
        raise HTTPException(404, "Origen no disponible.")
    doc = json.loads(r.payload_json)
    if doc.get("sha256") != ref or _huella([doc["pestana"], doc["clave"], doc["filas"]]) != ref:
        raise HTTPException(409, "La referencia no coincide con la huella archivada.")
    return doc


def _versiones(doc):
    filas = doc["filas"]
    fuente = doc["pestana"]
    versiones = {}
    if fuente == "Planeaciones_Versiones":
        grupos = defaultdict(list)
        for fila in filas:
            grupos[fila.get("Revision", "")].append(fila)
        for revision, piezas in grupos.items():
            try:
                payload, meta = reconstruir_planeacion(piezas, exigir_cadena=False)[0]
            except Incompatible:
                continue
            versiones[revision] = (payload, meta)
    elif fuente == "EPP_Versiones":
        try:
            versiones = {d["revision"]: (d, meta) for d, meta in reconstruir_epp(filas)}
        except Incompatible:
            pass
    else:
        raise HTTPException(422, "Esta fuente no usa un diario de revisiones comparable.")
    return versiones


def _vigente(db, doc):
    if doc["pestana"] == "Planeaciones_Versiones":
        fila = db.get(PlaneacionDoc, doc["clave"][0])
        if fila:
            from data.sql_repository import _serializar_planeacion
            payload = _serializar_planeacion(fila)
            return fila.revision, {k: payload.get(k) for k in ("datos", "metadatos", "tablas", "textos", "estado")}
    if doc["pestana"] == "EPP_Versiones" and len(doc["clave"]) == 2:
        alumno, ciclo = doc["clave"]
        filas = db.scalars(select(EPPDoc).where(EPPDoc.ciclo == ciclo,
                        EPPDoc.alumno.in_((alumno, "epp-" + alumno, "alu-uppcoder-" + alumno))).limit(2)).all()
        if len(filas) > 1:
            raise HTTPException(409, "Hay varias EPP operativas; no se seleccionó ninguna.")
        if filas:
            return filas[0].revision, json.loads(filas[0].partes_json or "{}")
    return None, {}


def _contenido(doc, dato):
    if doc["pestana"] == "EPP_Versiones":
        return dato["partes"]
    return {k: dato.get(k) for k in ("datos", "metadatos", "tablas", "textos", "estado")}


def _diferencias(a, b, prefijo=()):
    if isinstance(a, dict) and isinstance(b, dict):
        for clave in sorted(a.keys() | b.keys()):
            yield from _diferencias(a.get(clave), b.get(clave), (*prefijo, clave))
    elif a != b:
        yield {"campo": list(prefijo), "referencia": a, "origen": b}


def comparar(ref, revision=None, contra=None):
    with get_session(initialize_schema=False) as db:
        doc = _archivo(db, ref)
        versiones = _versiones(doc)
        rev_vigente, operativo = _vigente(db, doc)
        notas = db.scalars(select(Registro).where(Registro.modulo == MODULO, Registro.id_alumno == ref)
                           .order_by(Registro.fecha.desc()).limit(50)).all()
        resultado = {"operativa": rev_vigente,
                     "revisiones": [{"id": rid, "anterior": d.get("anterior") or (
                                        d.get("partes", {}).get(meta.get("parte"), {}).get("anterior", "")),
                                      "fecha": d.get("guardado_en") or d.get("fecha"),
                                      "area": meta.get("parte"), "autor": meta.get("autor")}
                                     for rid, (d, meta) in versiones.items()],
                     "decisiones": [json.loads(n.payload_json) for n in notas]}
        if revision:
            if revision not in versiones or (contra and contra not in versiones):
                raise HTTPException(404, "Revisión no disponible.")
            base = _contenido(doc, versiones[contra][0]) if contra else operativo
            cambios = list(_diferencias(base, _contenido(doc, versiones[revision][0])))
            # El respaldo JSON de origen completo sigue disponible para cambios extensos.
            resultado.update(diferencias=cambios[:50], total_diferencias=len(cambios))
        return resultado


def registrar(ref, revision, esperada, criterio, motivo, user):
    with get_session(initialize_schema=False) as db:
        doc = _archivo(db, ref)
        if revision not in _versiones(doc):
            raise HTTPException(404, "Revisión de origen no disponible.")
        vigente, _ = _vigente(db, doc)
        if vigente != esperada:
            raise HTTPException(409, "La revisión operativa cambió. Vuelve a comparar.")
        rid = uuid4().hex
        fecha = datetime.now(timezone.utc).isoformat()
        decision = {"id": rid, "referencia": ref, "revision_origen": revision, "revision_operativa": vigente,
                    "criterio": criterio, "motivo": motivo.strip(), "cuenta": user.usuario, "fecha": fecha}
        if not decision["motivo"]:
            raise HTTPException(422, "Registra el motivo de la decisión.")
        db.add(Registro(id=f"{MODULO}:{rid}", modulo=MODULO, registro_id=rid,
                        cuenta=user.usuario, id_alumno=ref, fecha=fecha, estado=criterio,
                        payload_json=json.dumps(decision, ensure_ascii=False)))
        db.commit()
        return decision
