"""Horario operativo: alcance escolar, bloqueo de revisión y escritura solo SQL."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import re
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import select

from data.database import ColeccionInstitucional as Registro, get_session
from piloto_spa.backend.domain_services import alcance_documentos_escolares, obtener_catalogo_escuelas
from utils.text import normalizar_texto

MODULO = "horarios_apoyo"
HISTORIAL = "horarios_revisiones"


def _escuela(user, valor):
    op = normalizar_texto(str(valor or ""))
    escuelas = [e for e in obtener_catalogo_escuelas() if op in
                {normalizar_texto(e["id"]), normalizar_texto(e["nombre"])}]
    if len(escuelas) != 1:
        raise HTTPException(422, "Selecciona una escuela del catálogo.")
    e = escuelas[0]
    if not alcance_documentos_escolares([{"ID_Escuela": e["id"]}],
                                        "DIRECTOR" if user.director else user.rol, user.escuelas_permitidas):
        raise HTTPException(403, "Escuela no autorizada.")
    return e


def _identidad(r, user):
    if not user.director and r.cuenta != user.usuario:
        raise HTTPException(404, "Horario no disponible.")
    _escuela(user, r.id_escuela)


def guardar(user, payload):
    if not user.director and user.area != "Aprendizaje":
        raise HTTPException(403, "La edición corresponde a Apoyo o Dirección.")
    escuela = _escuela(user, payload.get("id_escuela") or payload.get("escuela"))
    bloques = payload.get("bloques", payload.get("sesiones"))
    if not isinstance(bloques, list) or len(bloques) > 200 or any(
        not isinstance(b, dict) or b.get("Dia") not in ("Lunes","Martes","Miércoles","Jueves","Viernes")
        or not all(isinstance(b.get(k), str) and re.fullmatch(r"(?:[01][0-9]|2[0-3]):[0-5][0-9]", b[k])
                   for k in ("Inicio","Fin")) or b["Inicio"] >= b["Fin"] for b in bloques
    ) or len(json.dumps(bloques, ensure_ascii=False)) > 150000:
        raise HTTPException(422, "Revisa los días, horas y datos del horario.")
    rid = payload.get("id") or "horario-" + uuid4().hex
    if not isinstance(rid, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{1,80}", rid):
        raise HTTPException(422, "Identificador de horario inválido.")
    pk = f"{MODULO}:{rid}"
    with get_session(initialize_schema=False) as db:
        actual = db.scalar(select(Registro).where(Registro.id == pk, Registro.modulo == MODULO).with_for_update())
        fecha = datetime.now(timezone.utc).isoformat()
        if actual:
            _identidad(actual, user)
            previo = json.loads(actual.payload_json)
            if actual.id_escuela != escuela["id"] or previo.get("revision") != payload.get("revision"):
                raise HTTPException(409, "El horario cambió o corresponde a otra escuela. Vuelve a abrirlo.")
            ref = sha256((rid + ":" + actual.payload_json).encode()).hexdigest()
            anterior = Registro(id=f"{HISTORIAL}:{ref}", modulo=HISTORIAL, registro_id=ref,
                cuenta=actual.cuenta, id_escuela=actual.id_escuela, id_alumno=rid, fecha=actual.fecha,
                payload_json=actual.payload_json)
            if db.get(Registro, anterior.id) is None:
                db.add(anterior)
        else:
            if payload.get("id"):
                raise HTTPException(404, "Horario no disponible.")
            previo = {}
            actual = Registro(id=pk, modulo=MODULO, registro_id=rid, cuenta=user.usuario,
                              id_escuela=escuela["id"])
            db.add(actual)
        doc = {**previo, "id": rid, "revision": uuid4().hex, "id_escuela": escuela["id"],
               "escuela": escuela["nombre"], "maestra": previo.get("maestra") or user.nombre,
               "guardado_en": fecha, "bloques": bloques}
        actual.fecha = fecha
        actual.payload_json = json.dumps(doc, ensure_ascii=False)
        db.commit()
        return {"status": "success", "id": rid, "horario": doc}


def historial(user, rid):
    with get_session(initialize_schema=False) as db:
        actual = db.get(Registro, f"{MODULO}:{rid}")
        if actual is None or actual.modulo != MODULO:
            raise HTTPException(404, "Horario no disponible.")
        _identidad(actual, user)
        filas = db.scalars(select(Registro).where(Registro.modulo == HISTORIAL, Registro.id_alumno == rid,
                     Registro.id_escuela == actual.id_escuela).order_by(Registro.fecha.desc(), Registro.id)).all()
        return [{"ref": r.registro_id, "fecha": r.fecha, "horario": json.loads(r.payload_json)} for r in filas]
