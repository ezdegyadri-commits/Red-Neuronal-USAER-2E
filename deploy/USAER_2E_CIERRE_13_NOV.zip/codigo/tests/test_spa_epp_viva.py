import base64
from io import BytesIO
import os
import re
import secrets
import unittest

from fastapi.testclient import TestClient

from data.database import Alumno, Base, Escuela, Usuario, get_engine, get_session
from data.sql_repository import guardar_planeacion_sql
from piloto_spa.backend.auth_service import hash_password
from piloto_spa.backend.main import app


class EppYPlaneacion(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not re.fullmatch(
            r"postgresql\+psycopg2://usaer_qa@127\.0\.0\.1:55491/usaer_epp_noviembre_qa(?:_[a-f0-9]{8})?",
            os.environ.get("DATABASE_URL", ""),
        ):
            raise RuntimeError("La prueba solo admite la base local desechable usaer_epp_noviembre_qa.")
        engine = get_engine(initialize_schema=False)
        Base.metadata.create_all(engine)
        with get_session() as db:
            if db.query(Alumno).count() or db.query(Usuario).count():
                raise RuntimeError("Usa una base desechable vacía.")
            for i in (1, 2):
                db.add(Escuela(id=f"ESC-QA{i}", nombre_escuela=f"Escuela ficticia {i}"))
                db.add(Alumno(id=f"ALU-QA{i}", nombre_completo=f"Estudiante ficticio {i}",
                              id_escuela=f"ESC-QA{i}", nombre_escuela=f"Escuela ficticia {i}",
                              nivel_educativo="Primaria", grado="2", grupo="B", tipo_atencion="Grupal"))
            cls.password = secrets.token_urlsafe(24)
            for i, rol in enumerate(("APRENDIZAJE", "PSICOLOGIA", "APRENDIZAJE", "COMUNICACION",
                                     "TRABAJO SOCIAL", "DIRECTOR")):
                db.add(Usuario(id=f"QA-{i}", usuario=f"qa.{i}", nombre=f"Profesional ficticio {i}",
                               password=hash_password(cls.password), rol=rol,
                               escuelas_permitidas="ESC-QA2" if i == 2 else "ESC-QA1"))
            db.commit()
        for clave, modalidad in (("historica-ind", "individual"), ("historica-grupo", "grupal")):
            guardar_planeacion_sql({"id": clave, "cuenta": "qa.0", "formato": "XXIII",
                "estado": "BORRADOR", "revision": "importada", "datos": {
                    "ID_Escuela": "ESC-QA1", "Escuela regular": "Escuela ficticia 1",
                    "Curso escolar": "2026-2027", "Función": "Aprendizaje",
                    "Nombre del especialista": "Profesional ficticio 0",
                    "Alumnos": [{"ID_Alumno": "ALU-QA1", "Grado": "2", "Grupo": "B", "Condición": "",
                                 "Nombre del alumno": "Estudiante ficticio 1", "Tipo_Atencion": "Grupal"}]},
                "metadatos": {"modalidad_planeacion": modalidad, "guia_grupal_manual": {"filas": [
                    {"ID_Alumno": "ALU-QA1", "Psicología": "Aporte histórico ficticio"}
                ]} if modalidad == "grupal" else {}},
                "tablas": {"aprendizajes": [{"Descriptor de logro": "Identifica dos cantidades"}],
                           "dosificacion": [{"Fecha": "Semana 1", "Actividades": "Actividad histórica"}]},
                "textos": {"Evaluación": "Evidencia ficticia"}})

    def setUp(self):
        self.client = TestClient(app)
        self.headers = []
        for i in range(3):
            r = self.client.post("/api/auth/login", json={"usuario": f"qa.{i}", "password": self.password})
            self.assertEqual(r.status_code, 200, r.text)
            self.headers.append({"Authorization": "Bearer " + r.json()["token"]})

    def _cuenta(self, numero):
        r = self.client.post("/api/auth/login", json={"usuario": f"qa.{numero}", "password": self.password})
        self.assertEqual(r.status_code, 200, r.text)
        return {"Authorization": "Bearer " + r.json()["token"]}

    def test_novedades_autorizan_el_recurso_y_no_exponen_identidades(self):
        from unittest.mock import patch
        from piloto_spa.backend import main

        with (
            patch.object(main, "NOVEDADES_EN_VIVO", []),
            patch.object(main, "listar_alumnos", return_value=[{"id": "permitido"}]),
            patch.object(main, "listar_anexo3_endpoint", return_value=[]),
        ):
            main.registrar_novedad("alumnos", "permitido", "ACTUALIZADO", "qa.1")
            main.registrar_novedad("alumnos", "exclusivo-de-otra-docente", "CREADO", "qa.1")
            main.registrar_novedad("anexo3", "sin-acceso", "CREADO", "qa.1")
            main.registrar_novedad("alumnos", "permitido", "CREADO", "qa.0")
            r = self.client.get("/api/novedades-en-vivo", headers=self.headers[0])
            self.assertEqual(r.status_code, 200)
            self.assertEqual(r.json()["novedades"], [{"modulo": "alumnos", "accion": "ACTUALIZADO"}])
            self.assertEqual(set(r.json()), {"novedades", "servidor_tiempo"})
            self.assertGreaterEqual(
                self.client.get("/api/novedades-en-vivo").status_code, 400
            )

    def test_archivo_historico_proyeccion_y_descarga_privada(self):
        from hashlib import sha256
        from io import BytesIO
        from openpyxl import Workbook
        from reportlab.pdfgen.canvas import Canvas
        from data.database import Anexo5Evento, ColeccionInstitucional
        from tools.ampliar_recuperacion_historica import ARCHIVO, ampliar

        pdf = BytesIO()
        pagina = Canvas(pdf)
        pagina.drawString(72, 720, "Evidencia ficticia")
        pagina.save()
        binario = pdf.getvalue()
        book = Workbook()
        book.remove(book.active)
        for nombre, columnas, filas in (
            ("Anexo5_Eventos", ("ID_Evento", "ID_Alumno", "ID_Escuela", "Evento", "Estado"),
             (("QA-HECHO", "ALU-QA1", "ESC-QA1", "Evento histórico ficticio", "ACTIVO"),
              ("QA-DUP", "ALU-QA1", "ESC-QA1", "Versión uno", "ACTIVO"),
              ("QA-DUP", "ALU-QA1", "ESC-QA1", "Versión dos", "ACTIVO"),
              ("QA-ESCUELA", "ALU-QA1", "ESC-QA2", "Escuela distinta", "ACTIVO"))),
            ("Documentos_Expediente", ("ID_Documento", "Partes", "SHA256", "Nombre", "Mime",
                                       "ID_Alumnos_JSON", "ID_Escuela", "Estado", "Tipo", "Fecha"),
             (("QA-FILE", 1, sha256(binario).hexdigest(), "evidencia.pdf", "application/pdf",
               '["ALU-QA1"]', "ESC-QA1", "VIGENTE", "EPP", "2026-09-01"),
              ("QA-EMPTY", 1, sha256(binario).hexdigest(), "ausente.pdf", "application/pdf",
               '["ALU-QA1"]', "ESC-QA1", "VIGENTE", "EPP", "2026-09-01"))),
            ("Archivos_Expediente", ("ID_Documento", "Indice", "Total", "Contenido"),
             (("QA-FILE", 0, 1, base64.b64encode(binario).decode()),)),
        ):
            hoja = book.create_sheet(nombre)
            hoja.append(columnas)
            for fila in filas:
                hoja.append(fila)
        archivo = BytesIO()
        book.save(archivo)
        archivo.seek(0)
        cronograma = Workbook()
        cronograma.active.title = "Registros"
        cronograma.active.append(("ID_Publicacion", "Especialista", "Fecha", "Escuela", "Actividad"))
        cronograma.active.append(("QA-CRO", "Profesional ficticio", "2026-08-03", "Escuela ficticia 1", "Actividad ficticia"))
        archivo_cronograma = BytesIO()
        cronograma.save(archivo_cronograma)
        archivo_cronograma.seek(0)
        with get_session() as db:
            resultado = ampliar(db, archivo, aplicar=True, cronogramas=archivo_cronograma)
            db.commit()
        self.assertEqual(resultado["Anexo5_Eventos"]["incorporado"], 1)
        self.assertEqual(resultado["Anexo5_Eventos"]["id_repetido_con_contenido_distinto"], 1)
        self.assertEqual(resultado["Anexo5_Eventos"]["escuela_no_conciliada"], 1)
        self.assertEqual(resultado["Documentos_Expediente"]["adjunto_con_binario_verificado"], 1)
        self.assertEqual(resultado["Cronogramas_Registros"]["archivados_nuevos"], 1)
        try:
            archivo.seek(0)
            with get_session() as db:
                segundo = ampliar(db, archivo, aplicar=True)
                db.commit()
            self.assertEqual(segundo["Anexo5_Eventos"]["operativo_identico"], 1)
            self.assertEqual(segundo["Anexo5_Eventos"]["ya_archivados"], 3)
            c = self.client
            apoyo, _, otra = self.headers
            direccion = self._cuenta(5)
            admin = "/api/direccion/archivo-historico"
            self.assertEqual(c.get(admin, headers=apoyo).status_code, 403)
            indice = c.get(admin, headers=direccion, params={"pestana": "Anexo5_Eventos"}).json()
            ref = next(r["ref"] for r in indice["filas"] if r["estado"] == "id_repetido_con_contenido_distinto")
            self.assertEqual(c.get(admin + "/" + ref, headers=otra).status_code, 403)
            self.assertEqual(len(c.get(admin + "/" + ref, headers=direccion).json()["filas"]), 2)
            self.assertTrue(any(r["id"] == "QA-HECHO" for r in c.get("/api/anexo5", headers=apoyo).json()))
            ruta = "/api/expedientes/ALU-QA1/adjuntos-historicos"
            archivos = c.get(ruta, headers=apoyo).json()
            self.assertEqual([r["nombre"] for r in archivos], ["evidencia.pdf"])
            descarga = ruta + "/" + archivos[0]["ref"]
            self.assertEqual(c.get(descarga).status_code, 401)
            self.assertEqual(c.get(descarga, headers=otra).status_code, 404)
            self.assertEqual(c.get(descarga, headers=apoyo).content, binario)
        finally:
            with get_session() as db:
                db.query(Anexo5Evento).filter_by(id="QA-HECHO").delete()
                db.query(ColeccionInstitucional).filter_by(modulo=ARCHIVO).delete()
                db.commit()

    def test_cronograma_reabre_borrador_y_conserva_versiones_sin_publicar(self):
        from unittest.mock import patch
        from data.database import ColeccionInstitucional
        from tools.ampliar_recuperacion_historica import ARCHIVO, _registro_archivo

        mes = "2026-09"
        perfil = {"nombre": "Profesional ficticio 1", "area": "Psicología", "escuelas": ["Escuela ficticia 1"]}
        fecha = "2026-09-02"
        dias = {fecha: {"escuela": "Escuela ficticia 1", "actividad": "Observación de prueba"}}
        import json
        fuente = _registro_archivo("Borradores_Cronogramas", ("qa-origen", perfil["nombre"], mes),
            [{"ID_Version": "qa-origen", "Guardado_En": "2026-09-01T16:00:00-06:00",
              "Dias_JSON": json.dumps(dias)}], "pendiente_proyeccion")
        ref = fuente["registro_id"].split(":")[1]
        with get_session() as db:
            db.add(ColeccionInstitucional(**fuente))
            db.commit()
        c = self.client
        apoyo, psicologia, _ = self.headers
        comunicacion = self._cuenta(3)
        ruta = f"/api/cronogramas/borradores/{mes}"
        resolver = lambda nombre, rol: (perfil if "1" in nombre else {
            "nombre": nombre, "area": "Comunicación", "escuelas": ["Escuela ficticia 1"]})
        with patch("services.cronogramas.perfil_especialista", side_effect=resolver):
            self.assertEqual(c.get(ruta, headers=apoyo).status_code, 403)
            self.assertEqual(c.get(ruta + "/" + ref, headers=comunicacion).status_code, 404)
            self.assertEqual(c.get(ruta, headers=psicologia).json()["historicos"][0]["ref"], ref)
            self.assertEqual(c.get(ruta + "/" + ref, headers=psicologia).json()["dias"], dias)
            primera = c.post(ruta, headers=psicologia, json={"origen": ref, "dias": dias})
            self.assertEqual(primera.status_code, 200, primera.text)
            revision = primera.json()["revision"]
            self.assertEqual(c.post(ruta, headers=psicologia, json={"dias": dias}).status_code, 409)
            cambio = {fecha: {**dias[fecha], "actividad": "Seguimiento ficticio"}}
            nueva = c.post(ruta, headers=psicologia, json={"dias": cambio, "revision": revision})
            self.assertEqual(nueva.status_code, 200, nueva.text)
            self.assertEqual(c.get(ruta + "/" + revision, headers=psicologia).json()["dias"], dias)
            self.assertEqual(c.get(ruta, headers=psicologia).json()["actual"]["dias"], cambio)
            self.assertEqual(c.get(ruta + "/" + revision + "/pdf", headers=comunicacion).status_code, 404)
            self.assertTrue(c.get(ruta + "/" + revision + "/pdf", headers=psicologia).content.startswith(b"%PDF"))
            self.assertEqual(c.get("/api/cronogramas?mes=" + mes, headers=psicologia).json()["actividades"], [])
        with get_session() as db:
            db.query(ColeccionInstitucional).filter_by(id=fuente["id"], modulo=ARCHIVO).delete()
            db.query(ColeccionInstitucional).filter_by(modulo="cronogramas_borrador_vivo").delete()
            db.commit()

    def test_direccion_compara_y_registra_decision_sin_reemplazar(self):
        from hashlib import sha256
        import json
        from data.database import ColeccionInstitucional
        from tools.ampliar_recuperacion_historica import _registro_archivo
        filas = []
        for revision, anterior, nota in (("raiz", "", "A"), ("lado-uno", "raiz", "B"),
                                         ("lado-dos", "raiz", "C")):
            doc = {"id": "historica-ind", "cuenta": "qa.0", "formato": "XXIII", "estado": "BORRADOR",
                   "datos": {"ID_Escuela": "ESC-QA1", "Alumnos": [{"ID_Alumno": "ALU-QA1"}]},
                   "textos": {"Evaluación": nota}}
            contenido = json.dumps(doc, ensure_ascii=False)
            filas.append({"Documento": doc["id"], "Cuenta": "qa.0", "Formato": "XXIII",
                          "Estado": "BORRADOR", "Escuela_ID": "ESC-QA1", "Alumnos_JSON": '["ALU-QA1"]',
                          "Autor": "Profesional ficticio", "Revision": revision, "Anterior": anterior,
                          "Fecha": "2026-09-01", "Parte": "0", "Total": "1",
                          "SHA256": sha256(contenido.encode()).hexdigest(), "Contenido": contenido})
        fuente = _registro_archivo("Planeaciones_Versiones", ("historica-ind",), filas, "revisiones_en_rama")
        with get_session() as db:
            db.add(ColeccionInstitucional(**fuente))
            db.commit()
        c = self.client
        apoyo = self.headers[0]
        direccion = self._cuenta(5)
        ref = fuente["registro_id"].split(":")[1]
        ruta = "/api/direccion/archivo-historico/" + ref
        parametros = {"revision": "lado-dos", "contra": "lado-uno"}
        self.assertEqual(c.get(ruta + "/comparar", headers=apoyo, params=parametros).status_code, 403)
        comp = c.get(ruta + "/comparar", headers=direccion, params=parametros).json()
        self.assertEqual([r["anterior"] for r in comp["revisiones"]], ["", "raiz", "raiz"])
        self.assertEqual(comp["diferencias"], [{"campo": ["textos", "Evaluación"], "referencia": "B", "origen": "C"}])
        vigente = c.get("/api/planeaciones/historica-ind", headers=direccion).json()
        payload = {"revision": "lado-dos", "revision_operativa": "anterior-a-la-vigente",
                   "criterio": "REQUIERE_EVIDENCIA", "motivo": "Cotejo ficticio"}
        self.assertEqual(c.post(ruta + "/decisiones", headers=direccion, json=payload).status_code, 409)
        payload["revision_operativa"] = comp["operativa"]
        self.assertEqual(c.post(ruta + "/decisiones", headers=direccion, json=payload).status_code, 200)
        self.assertEqual(len(c.get(ruta + "/comparar", headers=direccion).json()["decisiones"]), 1)
        self.assertEqual(c.get("/api/planeaciones/historica-ind", headers=direccion).json()["revision"], vigente["revision"])

    def test_actas_y_oficios_respetan_escuela_tambien_en_url_directa(self):
        from data.database import OficioComision, RegistroVisita
        with get_session() as db:
            db.add(RegistroVisita(id="QA-VISITA", escuela="Escuela ficticia 1", fecha="2026-11-01",
                                  motivo="Visita ficticia", personal="Personal ficticio"))
            db.add(OficioComision(id="QA-OFICIO", id_escuela="ESC-QA1", escuela="Escuela ficticia 1",
                                  folio="QA-99", asunto="Asunto ficticio", estado="ACTIVO"))
            db.commit()
        try:
            c = self.client
            apoyo, _, otra = self.headers
            self.assertEqual(c.get("/api/visitas/QA-VISITA/pdf", headers=otra).status_code, 404)
            self.assertEqual(c.get("/api/oficios/QA-99/pdf", headers=otra).status_code, 404)
            self.assertEqual(c.get("/api/visitas/QA-VISITA/pdf", headers=apoyo).status_code, 200)
            self.assertTrue(any(r.get("Folio") == "QA-99" for r in c.get("/api/oficios", headers=apoyo).json()))
            self.assertEqual(c.get("/api/oficios/configuracion", headers=apoyo).status_code, 403)
            self.assertEqual(c.get("/api/admin/status-bd").status_code, 401)
            direccion = self._cuenta(5)
            self.assertEqual(c.post("/api/admin/auto-actualizar", headers=direccion).status_code, 410)
            resumen = c.get("/api/panel-direccion", headers=direccion)
            self.assertEqual(resumen.status_code, 200, resumen.text)
            self.assertEqual(resumen.json()["oficios_count"], 1)
        finally:
            with get_session() as db:
                db.query(RegistroVisita).filter_by(id="QA-VISITA").delete()
                db.query(OficioComision).filter_by(id="QA-OFICIO").delete()
                db.commit()

    def test_horario_revisado_conserva_anterior_y_rechaza_cruce(self):
        c = self.client
        apoyo, psicologia, otra = self.headers
        bloque = {"Dia": "Lunes", "Inicio": "08:00", "Fin": "08:45", "Proposito": "Actividad ficticia"}
        inicial = {"id_escuela": "ESC-QA1", "bloques": [bloque]}
        self.assertEqual(c.get("/api/horarios?escuela=ESC-QA1", headers=apoyo).json()["sesiones"], [])
        self.assertEqual(c.post("/api/horarios", headers=otra, json=inicial).status_code, 403)
        self.assertEqual(c.post("/api/horarios", headers=psicologia, json=inicial).status_code, 403)
        creado = c.post("/api/horarios", headers=apoyo, json=inicial)
        self.assertEqual(creado.status_code, 200, creado.text)
        doc = creado.json()["horario"]
        cambios = {**inicial, "id": doc["id"], "revision": doc["revision"],
                   "bloques": [{**bloque, "Proposito": "Actividad corregida"}]}
        self.assertEqual(c.post("/api/horarios", headers=apoyo, json=cambios).status_code, 200)
        self.assertEqual(c.post("/api/horarios", headers=apoyo, json=cambios).status_code, 409)
        ruta = f"/api/horarios/{doc['id']}/revisiones"
        self.assertEqual(c.get(ruta, headers=otra).status_code, 404)
        self.assertEqual(c.get(ruta, headers=apoyo).json()[0]["horario"]["bloques"], [bloque])
        self.assertEqual(c.get("/api/horarios?escuela=ESC-QA1", headers=otra).json()["sesiones"], [])
        self.assertEqual(c.get("/api/horarios?escuela=ESC-QA1", headers=apoyo).json()["sesiones"][0]["Proposito"],
                         "Actividad corregida")
        self.assertTrue(c.get("/api/horarios/pdf?escuela=ESC-QA1", headers=apoyo).content.startswith(b"%PDF"))

    def test_cinco_perfiles_y_apartados_epp(self):
        c = self.client
        apoyo, psicologia, otra = self.headers
        comunicacion, social, direccion = (self._cuenta(i) for i in (3, 4, 5))
        ruta = "/api/epp/ALU-QA1"
        ciclo = {"ciclo": "2024-2025"}
        inicio = c.post(ruta + "/iniciar", headers=apoyo, json=ciclo)
        self.assertEqual(inicio.status_code, 200)
        for headers, area in ((psicologia, "Psicología"), (comunicacion, "Comunicación"),
                              (social, "Trabajo Social"), (direccion, "Conclusión")):
            doc = c.get(ruta, params=ciclo, headers=headers).json()
            self.assertEqual(doc["editables"], [area])
            denegado = c.put(ruta + "/apartado", headers=headers, json={
                **ciclo, "area": "Aprendizaje", "revision": doc["revision"], "campos": {},
            })
            self.assertEqual(denegado.status_code, 403)
        self.assertEqual(c.get(ruta, params=ciclo, headers=otra).status_code, 404)

    def test_envio_planeacion_conserva_revision_y_protege_respaldo(self):
        c = self.client
        apoyo, psicologia, otra = self.headers
        ruta = "/api/planeaciones/historica-ind"
        anterior = c.get(ruta, headers=apoyo).json()
        self.assertEqual(c.put(ruta + "/enviar", headers=psicologia,
                               json={"revision": anterior["revision"]}).status_code, 403)
        envio = c.put(ruta + "/enviar", headers=apoyo, json={"revision": anterior["revision"]})
        self.assertEqual(envio.status_code, 200, envio.text)
        self.assertEqual(envio.json()["estado"], "ENVIADO")
        self.assertEqual(c.put(ruta + "/enviar", headers=apoyo,
                               json={"revision": anterior["revision"]}).status_code, 409)
        versiones = c.get(ruta + "/revisiones", headers=apoyo).json()
        previa = next(v for v in versiones if v["revision"] == anterior["revision"])
        respaldo = ruta + "/revisiones/" + previa["id"]
        self.assertEqual(c.get(respaldo, headers=otra).status_code, 403)
        self.assertEqual(c.get(respaldo, headers=apoyo).json()["textos"]["Evaluación"], "Evidencia ficticia")

    def test_indice_no_trunca_documentos_autorizados(self):
        from data.database import PlaneacionDoc

        with get_session() as db:
            db.execute(PlaneacionDoc.__table__.insert(), [{
                "id": f"qa-paginacion-{i:03d}", "cuenta": "qa.0", "revision": f"rev-{i}",
                "datos_json": '{"ID_Escuela":"ESC-QA1","Alumnos":[{"ID_Alumno":"ALU-QA1"}]}',
                "metadatos_json": '{"modalidad_planeacion":"individual"}',
            } for i in range(510)])
            db.commit()
        try:
            docs = self.client.get("/api/planeaciones", headers=self.headers[0]).json()
            self.assertEqual(sum(d["id"].startswith("qa-paginacion-") for d in docs), 510)
        finally:
            with get_session() as db:
                db.query(PlaneacionDoc).filter(PlaneacionDoc.id.startswith("qa-paginacion-")).delete()
                db.commit()

    def test_importacion_historica_no_duplica_ni_sobrescribe(self):
        from hashlib import sha256
        import json
        from data.database import get_engine
        from tools.recuperacion_documental import Documento, Incompatible, conciliar, reconstruir_epp, reconstruir_planeacion

        plan = {"id": "historica-importada-sintetica", "cuenta": "qa.0", "estado": "BORRADOR", "formato": "XXIII",
                "datos": {"ID_Escuela": "ESC-QA1", "Curso escolar": "2023-2024",
                          "Alumnos": [{"ID_Alumno": "ALU-QA1"}]},
                "metadatos": {"modalidad_planeacion": "individual"}, "tablas": {}, "textos": {}}
        filas = []
        for revision, previo, texto in (("primera", "", "Anterior"), ("segunda", "primera", "Vigente")):
            payload = json.dumps({**plan, "textos": {"Evaluación": texto}}, ensure_ascii=False)
            fila = {"Documento": plan["id"], "Revision": revision, "Anterior": previo, "Fecha": "2024-06-01",
                    "Cuenta": "qa.0", "Autor": "Autor ficticio", "Escuela_ID": "ESC-QA1",
                    "Alumnos_JSON": '["ALU-QA1"]', "Formato": "XXIII", "Estado": "BORRADOR",
                    "Total": "2", "SHA256": sha256(payload.encode()).hexdigest()}
            filas += [{**fila, "Parte": str(i), "Contenido": p} for i, p in
                      enumerate((payload[:25], payload[25:]))]
        with self.assertRaisesRegex(Incompatible, "fragmentos_incompletos"):
            reconstruir_planeacion(filas[:-1])
        versiones = reconstruir_planeacion(list(reversed(filas)))
        epp = reconstruir_epp([
            {"Alumno": "ALU-QA1", "Ciclo": "2023-2024", "Parte": "META", "Revision": "epp-inicio",
             "Anterior": "", "Fecha": "2024-06-01", "Cuenta": "qa.0", "Autor": "Autor ficticio",
             "Estado": "BORRADOR", "Contenido": '{"creada_por":"qa.0"}'},
            {"Alumno": "ALU-QA1", "Ciclo": "2023-2024", "Parte": "Aprendizaje", "Revision": "epp-area",
             "Anterior": "", "Fecha": "2024-06-01", "Cuenta": "qa.0", "Autor": "Autor ficticio",
             "Estado": "BORRADOR", "Contenido": '{"sintesis":"Observación histórica ficticia"}'},
        ])
        documentos = [Documento("planeaciones", versiones), Documento("epp", epp)]
        engine = get_engine(initialize_schema=False)
        with engine.begin() as db:
            self.assertEqual(conciliar(db, documentos)["planeaciones"]["faltantes"], 1)
        with engine.begin() as db:
            recuperados = conciliar(db, documentos, aplicar=True)
        self.assertEqual(recuperados["planeaciones"]["recuperados"], 1)
        self.assertEqual(recuperados["epp"]["recuperados"], 1)
        with engine.begin() as db:
            repeticion = conciliar(db, documentos, aplicar=True)
        self.assertEqual(repeticion["planeaciones"]["conciliados"], 1)
        self.assertNotIn("recuperados", repeticion["epp"])
        c, apoyo = self.client, self.headers[0]
        endpoint = "/api/planeaciones/" + plan["id"]
        historial = c.get(endpoint + "/revisiones", headers=apoyo).json()
        self.assertEqual(historial[0]["revision"], "primera")
        actual = c.get(endpoint, headers=apoyo).json()
        self.assertEqual(actual["textos"]["Evaluación"], "Vigente")
        guardado = c.post("/api/planeaciones", headers=apoyo,
                          json={**actual, "textos": {"Evaluación": "Edición posterior"}})
        self.assertEqual(guardado.status_code, 200, guardado.text)
        with engine.begin() as db:
            conflictos = conciliar(db, documentos, aplicar=True)
        self.assertEqual(conflictos["planeaciones"]["conflictos_preservados"], 1)
        self.assertEqual(c.get(endpoint, headers=apoyo).json()["textos"]["Evaluación"], "Edición posterior")
        from data.database import ColeccionInstitucional, EPPDoc, PlaneacionDoc
        with get_session() as db:
            db.query(ColeccionInstitucional).filter(ColeccionInstitucional.registro_id.startswith(plan["id"] + ":")).delete()
            db.query(PlaneacionDoc).filter_by(id=plan["id"]).delete()
            db.query(EPPDoc).filter_by(id=epp[-1][0]["id"]).delete()
            db.commit()

    def test_formato_vivo_y_colaboracion(self):
        c = self.client
        apoyo, psicologia, otra = self.headers
        ruta = "/api/epp/ALU-QA1"
        self.assertEqual(c.get(ruta, headers=otra).status_code, 404)
        self.assertEqual(c.get(ruta).status_code, 401)
        d = c.get(ruta, headers=apoyo).json()
        self.assertIsNone(d["revision"])
        guardar = {"area": "Aprendizaje", "ciclo": d["ciclo"], "revision": d["revision"],
                   "campos": {"4.1. Orientación temporal": "Ordena tres tarjetas con ayuda."},
                   "sintesis": "NEE: Necesita ordenar las secuencias de la rutina."}
        self.assertEqual(c.put(ruta+"/apartado", headers=psicologia, json=guardar).status_code, 403)
        r = c.put(ruta+"/apartado", headers=apoyo, json=guardar)
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(c.put(ruta+"/apartado", headers=apoyo, json=guardar).status_code, 409)
        psi = {"area": "Psicología", "ciclo": d["ciclo"], "revision": r.json()["revision"],
               "campos": {"3.1. Atención": "Atiende a una consigna breve."}}
        r = c.put(ruta+"/apartado", headers=psicologia, json=psi)
        self.assertEqual(r.status_code, 200, r.text)
        self.assertIn("Ordena tres tarjetas", r.json()["partes"]["Aprendizaje"]["contenido"]["campos"]["4.1. Orientación temporal"])
        propuesta = {"area": "Conclusión", "ciclo": d["ciclo"]}
        p = c.post(ruta+"/propuesta", headers=apoyo, json=propuesta).json()
        self.assertIn("Psicología", p["campos"]["7.1. Conclusión"])
        self.assertTrue(any("secuencias" in row["NEE"] for row in p["nee"]))
        self.assertFalse(any(row["Tipo de barrera"] for row in p["bap"]))
        import pymupdf
        pdf = c.get(ruta+"/pdf", headers=apoyo)
        self.assertEqual(pdf.status_code, 200)
        with pymupdf.open(stream=pdf.content, filetype="pdf") as documento:
            texto = " ".join(pagina.get_text() for pagina in documento)
        self.assertIn("Nivel educativo: Primaria", texto)
        self.assertIn("Necesita ordenar las secuencias de la rutina.", texto)

    def test_lectura_de_archivos_y_permiso(self):
        from docx import Document
        from reportlab.pdfgen.canvas import Canvas

        ruta = "/api/epp/ALU-QA2/propuesta"
        apoyo, _, otra = self.headers
        docx = Document()
        docx.add_paragraph("En lectura identifica dos palabras con tarjetas.")
        buf_docx = BytesIO()
        docx.save(buf_docx)
        buf_pdf = BytesIO()
        pdf = Canvas(buf_pdf)
        pdf.drawString(72, 720, "En lectura identifica dos palabras con tarjetas.")
        pdf.save()
        for nombre, data in (("evidencia.txt", b"En lectura identifica dos palabras con tarjetas."),
                             ("evidencia.docx", buf_docx.getvalue()), ("evidencia.pdf", buf_pdf.getvalue())):
            payload = {"area": "Aprendizaje", "ciclo": "2026-2027", "campo": "4.1. Lectura y escritura funcional",
                       "archivo_nombre": nombre, "archivo_base64": base64.b64encode(data).decode()}
            self.assertEqual(self.client.post(ruta, headers=apoyo, json=payload).status_code, 404)
            r = self.client.post(ruta, headers=otra, json=payload)
            self.assertEqual(r.status_code, 200, r.text)
            self.assertIn("dos palabras", r.json()["texto"])
            self.assertEqual(len(r.json()["archivo_sha256"]), 64)

    def test_recuperacion_individual_grupal_y_aislamiento(self):
        apoyo, _, otra = self.headers
        docs = self.client.get("/api/planeaciones", headers=apoyo).json()
        self.assertEqual({d["modalidad"] for d in docs}, {"individual", "grupal"})
        self.assertEqual(self.client.get("/api/planeaciones", headers=otra).json(), [])
        r = self.client.get("/api/planeaciones/historica-grupo", headers=apoyo)
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(r.json()["guia_grupal"]["filas"][0]["Psicología"], "Aporte histórico ficticio")
        self.assertEqual(r.json()["tablas"]["dosificacion"][0]["Temporalidad"], "Semana 1")
        self.assertEqual(self.client.get("/api/planeaciones/historica-grupo", headers=otra).status_code, 403)
        self.assertEqual(self.client.get("/api/planeaciones/no-existe", headers=apoyo).status_code, 404)
        vinculos = "/api/expedientes/ALU-QA1/planeaciones"
        r = self.client.get(vinculos, headers=apoyo)
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual({p["modalidad"] for p in r.json()}, {"individual", "grupal"})
        self.assertEqual(self.client.get(vinculos, headers=otra).status_code, 404)

    def test_ciclo_de_vida_epp_y_revisiones_autorizadas(self):
        c = self.client
        apoyo, psicologia, otra = self.headers
        ruta = "/api/epp/ALU-QA1"
        periodo = {"ciclo": "2025-2026"}
        self.assertEqual(c.post(ruta + "/iniciar", headers=psicologia, json=periodo).status_code, 403)
        creada = c.post(ruta + "/iniciar", headers=apoyo, json=periodo)
        self.assertEqual(creada.status_code, 200, creada.text)
        self.assertEqual(c.post(ruta + "/iniciar", headers=apoyo, json=periodo).json()["revision"], creada.json()["revision"])
        guardada = c.put(ruta + "/apartado", headers=psicologia, json={
            **periodo, "revision": creada.json()["revision"], "area": "Psicología",
            "campos": {"3.1. Atención": "Hallazgo anterior ficticio"},
        })
        self.assertEqual(guardada.status_code, 200, guardada.text)
        cambio = {**periodo, "revision": guardada.json()["revision"]}
        self.assertEqual(c.put(ruta + "/vigencia/retirar", headers=psicologia, json=cambio).status_code, 403)
        retirada = c.put(ruta + "/vigencia/retirar", headers=apoyo, json=cambio)
        self.assertEqual(retirada.status_code, 200, retirada.text)
        self.assertEqual(retirada.json()["editables"], [])
        self.assertEqual(c.put(ruta + "/vigencia/recuperar", headers=apoyo, json=cambio).status_code, 409)
        recuperada = c.put(ruta + "/vigencia/recuperar", headers=apoyo,
                           json={**periodo, "revision": retirada.json()["revision"]})
        self.assertEqual(recuperada.json()["estado"], "BORRADOR")
        historial = c.get(ruta + "/revisiones", headers=apoyo, params=periodo).json()
        self.assertEqual(len(historial), 3)
        version = ruta + "/revisiones/" + next(r["id"] for r in historial if r["revision"] == cambio["revision"])
        self.assertEqual(c.get(version, headers=otra, params=periodo).status_code, 404)
        previa = c.get(version, headers=psicologia, params=periodo).json()
        self.assertEqual(previa["editables"], [])
        self.assertEqual(previa["partes"]["Psicología"]["contenido"]["campos"]["3.1. Atención"], "Hallazgo anterior ficticio")

    def test_anexos_corrigen_persisten_reactivan_y_aislan_pdf(self):
        c = self.client
        apoyo, psicologia, otra = self.headers
        for numero, campo in ((3, "fisicas"), (4, "sugerencias"), (5, "evento")):
            with self.subTest(anexo=numero):
                ruta = f"/api/anexo{numero}"
                r = c.post(ruta, headers=apoyo, json={"id_alumno": "ALU-QA1", campo: "Dato inicial"})
                self.assertEqual(r.status_code, 200, r.text)
                ident = r.json()["id"]
                documento = ruta + "/" + ident
                self.assertEqual(next(a for a in c.get(ruta, headers=apoyo).json() if a["id"] == ident)[campo], "Dato inicial")
                self.assertEqual(c.get(documento + "/pdf", headers=otra).status_code, 404)
                self.assertEqual(c.put(documento, headers=psicologia, json={campo: "Cambio ajeno"}).status_code, 403)
                self.assertEqual(c.delete(documento, headers=otra).status_code, 404)
                self.assertEqual(c.put(documento, headers=apoyo, json={campo: "Corrección sintética"}).status_code, 200)
                listado = c.get(ruta, headers=apoyo).json()
                self.assertEqual(next(a for a in listado if a["id"] == ident)[campo], "Corrección sintética")
                pdf = c.get(documento + "/pdf", headers=apoyo)
                self.assertEqual(pdf.status_code, 200, pdf.text[:100] if pdf.status_code != 200 else "")
                self.assertTrue(pdf.content.startswith(b"%PDF"))
                self.assertEqual(c.delete(documento, headers=apoyo).status_code, 200)
                self.assertFalse(any(a["id"] == ident for a in c.get(ruta, headers=apoyo).json()))
                self.assertTrue(any(a["id"] == ident for a in c.get(ruta, headers=apoyo, params={"incluir_retirados": True}).json()))
                self.assertEqual(c.put(f"/api/anexo/{numero}/{ident}/reactivar", headers=apoyo).status_code, 200)
                self.assertTrue(any(a["id"] == ident for a in c.get(ruta, headers=apoyo).json()))
        self.assertEqual(c.post("/api/anexo7", headers=otra, json={"id_alumno": "ALU-QA1"}).status_code, 404)
        self.assertEqual(c.get("/api/expedientes/GRUPO-ESC-QA1-2-B", headers=apoyo).status_code, 404)
        expediente = c.get("/api/expedientes/ALU-QA1", headers=apoyo)
        self.assertEqual(expediente.status_code, 200)
        self.assertEqual(expediente.json()["linea_tiempo"][0]["ID_Registro"], ident)

    def test_cronograma_historico_filtra_mes_y_no_inventa_actividades(self):
        from data.sql_repository import coleccion_guardar_sql

        c = self.client
        apoyo, psicologia, otra = self.headers
        coleccion_guardar_sql("cronogramas", "cronograma-legado-ficticio", {
            "Especialista": "Profesional ficticio 1", "Fecha": "06/10/2026",
            "Actividad": "Visita ficticia registrada", "Estado": "ACTIVO",
        }, solo_sql=True)
        octubre = c.get("/api/cronogramas", params={"mes": "Octubre 2026"}, headers=psicologia)
        self.assertEqual(octubre.status_code, 200, octubre.text)
        self.assertEqual([a["Actividad"] for a in octubre.json()["actividades"]], ["Visita ficticia registrada"])
        for cuenta, mes in ((otra, "Octubre 2026"), (psicologia, "Noviembre 2026")):
            self.assertEqual(c.get("/api/cronogramas", params={"mes": mes}, headers=cuenta).json()["actividades"], [])
        self.assertEqual(c.get("/api/cronogramas/pdf", params={"mes": "Noviembre 2026"}, headers=psicologia).status_code, 404)
        self.assertEqual(c.post("/api/cronogramas", headers=apoyo, json={"mes": "Octubre 2026", "actividades": []}).status_code, 403)

    def test_nee_exige_conclusion_vigente_del_mismo_ciclo(self):
        from data.sql_repository import epp_listar_sql, guardar_epp_sql
        from services.epp_modelo import AREAS, clave

        c = self.client
        apoyo, _, otra = self.headers
        ruta = "/api/planeaciones/historica-ind/nee-confirmadas"
        ciclo = "2026-2027"
        alumno = "ALU-QA1"
        doc = {"id": clave(alumno, ciclo), "alumno": alumno, "ciclo": ciclo, "revision": "sintetica",
               "partes": {a: {"revision": str(i)} for i, a in enumerate(AREAS)}}
        doc["partes"]["Conclusión"] = {"revision": "validada", "contenido": {
            "validada": True, "revisiones_areas": {a: str(i) for i, a in enumerate(AREAS)},
            "nee": [{"NEE": "Necesita ordenar tres secuencias."}, {"NEE": "Sin evidencia"}],
        }}
        original = next((e for e in epp_listar_sql([alumno]) if e["id"] == doc["id"]), None)
        guardar_epp_sql(doc)
        try:
            self.assertEqual(c.get(ruta, headers=otra).status_code, 403)
            r = c.get(ruta, headers=apoyo)
            self.assertEqual(r.status_code, 200, r.text)
            self.assertEqual([n["NEE"] for n in r.json()[0]["nee"]], ["Necesita ordenar tres secuencias."])
            doc["partes"]["Psicología"]["revision"] = "posterior"
            guardar_epp_sql(doc)
            self.assertEqual(c.get(ruta, headers=apoyo).json(), [])
        finally:
            if original:
                guardar_epp_sql(original)
            else:
                # Esta prueba corre en la base desechable validada por setUpClass.
                from data.database import EPPDoc
                with get_session() as db:
                    db.query(EPPDoc).filter_by(id=doc["id"]).delete()
                    db.commit()

    def test_retiro_planeacion_conserva_aportes_y_permite_recuperar(self):
        apoyo, psicologia, otra = self.headers
        c = self.client
        ruta = "/api/planeaciones/historica-grupo"
        self.assertEqual(c.delete(ruta, headers=psicologia).status_code, 404)
        self.assertEqual(c.delete(ruta, headers=apoyo).status_code, 200)
        self.assertEqual(c.get(ruta, headers=apoyo).status_code, 403)
        self.assertEqual(c.get("/api/planeaciones?solo_retiradas=true", headers=otra).json(), [])
        retiradas = c.get("/api/planeaciones?solo_retiradas=true", headers=apoyo).json()
        self.assertEqual([d["id"] for d in retiradas], ["historica-grupo"])
        self.assertEqual(c.put(ruta + "/recuperar", headers=psicologia).status_code, 404)
        self.assertEqual(c.put(ruta + "/recuperar", headers=apoyo).status_code, 200)
        reopened = c.get(ruta, headers=apoyo).json()
        self.assertEqual(reopened["estado"], "BORRADOR")
        self.assertEqual(reopened["guia_grupal"]["filas"][0]["Psicología"], "Aporte histórico ficticio")
