const assert = require("node:assert/strict");
const { readFile } = require("node:fs/promises");
const { performance } = require("node:perf_hooks");
const { chromium } = require(process.env.USAER_PLAYWRIGHT || "playwright");

(async () => {
  const base = process.env.USAER_NAVEGADOR_URL;
  if (base !== "http://127.0.0.1:18173") throw Error("Solo se admite la SPA QA local.");
  const browser = await chromium.launch({channel:"msedge", headless:true});
  const perfiles = [[0,"Aprendizaje"], [1,"Psicología"], [3,"Comunicación"], [4,"Trabajo Social"], [5,"Conclusión"]];
  const errores = [], medidas = {};
  const medir = async (op, f) => {
    const inicio = performance.now(), res = await f();
    (medidas[op] ??= []).push(Math.round(performance.now()-inicio));
    return res;
  };
  const ingresar = async (numero) => {
    const ctx = await browser.newContext({ viewport:{width:1480,height:1000},acceptDownloads:true });
    await ctx.route("**/*", r => r.request().url().startsWith(base+"/") ? r.continue() : r.abort());
    const p = await ctx.newPage();
    p.setDefaultTimeout(15000);
    p.on("pageerror", e=>errores.push(e.message));
    p.on("response", r=>{if(r.url().startsWith(base+"/api/") && r.status()>=500) errores.push("API "+r.status());});
    await p.goto(base);
    await p.locator('input[type=text]').first().fill('qa.'+numero);
    await p.locator('input[type=password]').fill(process.env.USAER_NAVEGADOR_CLAVE);
    await p.getByRole("button",{name:/Entrar al Sistema/}).click();
    await p.getByRole("button",{name:/Alumnos y Expedientes/}).waitFor();
    return p;
  };
  const status = (p,ruta) => p.evaluate(async ruta=>{
    const token = sessionStorage.getItem("usaer_token") || sessionStorage.getItem("token");
    const r = await fetch(ruta,{headers:{Authorization:"Bearer "+token}});
    return r.status;
  },ruta);
  const abrir = async p => {
    await p.getByRole("button",{name:/^📋 EPP$/}).click();
    await p.locator("main form select").first().selectOption("ALU-QA1");
    await medir("abrir_epp",async()=>{
      await p.getByRole("button",{name:"Abrir formato vivo"}).click();
      await p.getByRole("heading",{name:/EPP · Estudiante ficticio 1/}).waitFor();
    });
  };
  try {
    for (const [num,area] of perfiles) {
      const p = await ingresar(num);
      await abrir(p);
      if(num===0) {
        await p.getByRole("button",{name:"Iniciar EPP"}).click();
        await p.getByText("EPP iniciada",{exact:true}).waitFor();
      }
      const campoArea = (titulo) => p.locator("label").filter({has:p.getByText(titulo,{exact:true})}).locator("textarea");
      const campo = campoArea(num===5 ? "7.1. Conclusión" : "Síntesis");
      assert(await campo.isEditable());
      await campo.fill("Registro sintético "+area);
      await medir("guardar_epp",async()=>{
        await p.getByRole("button",{name:"Guardar borrador"}).click();
        await p.getByText("Borrador guardado",{exact:true}).waitFor();
      });
      await p.getByRole("button",{name:"← Volver a la lista"}).click();
      await medir("reabrir_epp",async()=>{
        await p.getByRole("button",{name:"Abrir EPP",exact:true}).first().click();
        await campo.waitFor();
      });
      assert.equal(await campo.inputValue(),"Registro sintético "+area);
      if(num!==5) {
        await p.getByRole("button",{name:num===0?"Psicología":"Aprendizaje",exact:true}).click();
        assert.equal(await campoArea("Síntesis").isEditable(),false);
        assert.equal(await status(p,"/api/expedientes/ALU-QA2"),404);
        assert.equal(await status(p,"/api/direccion/archivo-historico"),403);
      } else {
        await p.getByRole("button",{name:"Panel de Dirección"}).click();
        await p.getByRole("button",{name:"Archivo histórico",exact:true}).click();
        await p.getByRole("button",{name:"Consultar cortes y conflictos",exact:true}).click();
        await p.getByText(/Doble lectura coincidente/).waitFor();
        const conflicto=p.locator("li").filter({hasText:"edicion en ambos origenes"});
        await conflicto.waitFor();
        const [local] = await Promise.all([p.waitForEvent("download"),
          conflicto.getByRole("button",{name:"PostgreSQL",exact:true}).click()]);
        assert.equal(JSON.parse(await readFile(await local.path(),"utf8")).postgresql.evento,"Edición local conservada");
        await p.locator("main section select").last().selectOption("Anexo5_Eventos");
        await p.getByText("id repetido con contenido distinto",{exact:false}).waitFor();
        const [respaldo] = await Promise.all([p.waitForEvent("download"),
          p.locator("li").filter({hasText:"id repetido con contenido distinto"})
            .getByRole("button",{name:"Descargar registro original"}).click()]);
        assert.equal(JSON.parse(await readFile(await respaldo.path(),"utf8")).filas.length,2);
        await p.locator("main section select").last().selectOption("Planeaciones_Versiones");
        await p.getByRole("button",{name:"Comparar",exact:true}).click();
        await p.getByRole("heading",{name:"Conciliar revisiones"}).locator("..")
          .locator("select").first().selectOption("qa-segunda");
        await p.getByRole("button",{name:"Ver diferencias",exact:true}).click();
        await p.getByText("textos / Evaluación",{exact:true}).waitFor();
        await p.getByLabel("Motivo",{exact:true}).fill("Decisión ficticia");
        await p.getByRole("button",{name:"Registrar decisión"}).click();
        await p.getByText("Decisión registrada. Se conservaron ambas versiones.").waitFor();
        await abrir(p);
      }
      await medir("historial_epp",async()=>{
        await p.getByRole("button",{name:"Consultar revisiones"}).click();
        await p.getByRole("heading",{name:"Revisiones anteriores"}).waitFor();
      });
      if(num===5) {
        const [pdf] = await medir("descargar_pdf",()=>Promise.all([p.waitForEvent("download"),
          p.getByRole("button",{name:"Descargar PDF"}).click()]));
        assert.equal(pdf.suggestedFilename(),"EPP.pdf");
        assert((await readFile(await pdf.path())).subarray(0,5).equals(Buffer.from("%PDF-")));
        if(process.env.USAER_NAVEGADOR_PDF) await pdf.saveAs(process.env.USAER_NAVEGADOR_PDF);
        await medir("abrir_expediente",async()=>{
          await p.getByRole("button",{name:"Abrir expediente"}).click();
          await p.getByRole("button",{name:"Consultar adjuntos históricos"}).waitFor();
        });
        await medir("cambiar_alumno",async()=>{
          await p.getByText("Estudiante ficticio 2",{exact:true}).first().click();
          await p.getByRole("heading",{name:"Estudiante ficticio 2",exact:true}).waitFor();
        });
      }
      if(num===0) {
        await p.getByRole("button",{name:/Todos los Módulos/}).click();
        await p.getByRole("button",{name:/Horarios de Apoyo/}).click();
        const agregar=p.getByRole("button",{name:"+ Agregar Bloque",exact:true});
        const texto=p.getByPlaceholder(/Ej\. Acompañamiento DUA/);
        const confirmar=p.getByRole("button",{name:"Agregar Bloque",exact:true});
        await agregar.click();
        await texto.fill("Bloque de prueba en Edge");
        await confirmar.click();
        await p.getByText("Bloque de prueba en Edge",{exact:true}).waitFor();
        await p.getByRole("button",{name:"Editar bloque",exact:true}).click();
        assert.equal(await texto.inputValue(),"Bloque de prueba en Edge");
        await texto.fill("Bloque editado en Edge");
        await confirmar.click();
        await p.getByText("Bloque editado en Edge",{exact:true}).waitFor();
        await p.getByRole("button",{name:"Consultar revisiones del horario"}).click();
        await p.getByText(/ · 1 bloques/).waitFor();
        const [horario] = await Promise.all([p.waitForEvent("download"),
          p.getByRole("button",{name:/Descargar PDF Oficial/}).click()]);
        assert((await readFile(await horario.path())).subarray(0,5).equals(Buffer.from("%PDF-")));
        console.log("Horario: alta, edición, guardado, historial y PDF.");
      }
      if(num===1) {
        await p.getByRole("button",{name:/Todos los Módulos/}).click();
        await p.getByRole("button",{name:/Cronograma Mensual/}).click();
        await p.getByRole("button",{name:"Consultar borradores",exact:true}).click();
        const selector=p.getByRole("heading",{name:"Borradores privados de cronograma"}).locator("..").locator("select").first();
        await selector.locator("option").filter({hasText:"Streamlit"}).waitFor({state:"attached"});
        await selector.selectOption({index:1});
        const campo=p.getByLabel("Actividad 2026-11-04",{exact:true});
        assert.equal(await campo.inputValue(),"Actividad de origen");
        await campo.fill("Actividad editada en Edge");
        await p.getByRole("button",{name:"Guardar borrador",exact:true}).click();
        await p.getByText("Borrador guardado.",{exact:true}).waitFor();
        const [pdf] = await Promise.all([p.waitForEvent("download"),
          p.getByRole("button",{name:"PDF del borrador",exact:true}).click()]);
        assert((await readFile(await pdf.path())).subarray(0,5).equals(Buffer.from("%PDF-")));
        await selector.selectOption({index:2});
        await p.getByText(/Versión abierta/).waitFor();
        assert.equal(await campo.inputValue(),"Actividad de origen");
        console.log("Cronograma: recuperación, guardado como revisión, PDF y reapertura del original.");
        await p.getByRole("button",{name:"Consultar publicaciones históricas"}).click();
        const historial = p.getByLabel("Publicación histórica",{exact:true});
        await historial.selectOption({label:"Profesional ficticio 1 · 2026-11-01 · qa-publicacion · 1 registros"});
        await p.getByText("Histórico · vigencia no confirmada",{exact:true}).waitFor();
        await p.getByText(/Publicación sintética anterior · SUSTITUIDO/).waitFor();
        const [hist] = await Promise.all([p.waitForEvent("download"),
          p.getByRole("button",{name:"Descargar PDF histórico"}).click()]);
        assert((await readFile(await hist.path())).subarray(0,5).equals(Buffer.from("%PDF-")));
        const pubRef=await historial.inputValue();
        const otraCuenta=await ingresar(2);
        assert.equal(await status(otraCuenta,"/api/cronogramas/historicos/2026-11/"+pubRef+"/pdf"),403);
        await otraCuenta.context().close();
      }
      const token = await p.evaluate(()=>sessionStorage.getItem("usaer_token"));
      await p.getByRole("button",{name:"Salir",exact:true}).click();
      await p.getByRole("button",{name:/Entrar al Sistema/}).waitFor();
      assert.equal(await p.evaluate(()=>sessionStorage.getItem("usaer_token")),null);
      assert.equal(await p.evaluate(async token=>
        (await fetch("/api/me",{headers:{Authorization:"Bearer "+token}})).status,token),401);
      await p.context().close();
      console.log(area+": guardado, reapertura, historial y alcance correctos");
    }
    for (const [num,propio,ajeno] of [[6,"ALU-QA-A","ALU-QA-B"],[7,"ALU-QA-B","ALU-QA-A"]]) {
      const p=await ingresar(num);
      await p.getByRole("button",{name:/^📋 EPP$/}).click();
      await p.locator('option[value="'+propio+'"]').waitFor({state:"attached"});
      assert.equal(await p.locator('option[value="'+ajeno+'"]').count(),0);
      assert.equal(await status(p,"/api/expedientes/"+ajeno),404);
      const edicion = await p.evaluate(async id => {
        const token=sessionStorage.getItem("usaer_token") || sessionStorage.getItem("token");
        const r=await fetch("/api/epp/"+id+"/apartado",{method:"PUT",
          headers:{Authorization:"Bearer "+token,"Content-Type":"application/json"},
          body:JSON.stringify({area:"Aprendizaje",ciclo:"2026-2027",revision:null,campos:{}})});
        return r.status;
      },ajeno);
      assert.equal(edicion,404);
      await p.context().close();
    }
    assert.deepEqual(errores,[]);
    console.log("Dos docentes en una escuela: lectura y escritura cruzadas denegadas en ambas direcciones.");
    console.log(JSON.stringify(medidas));
  } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1;});
