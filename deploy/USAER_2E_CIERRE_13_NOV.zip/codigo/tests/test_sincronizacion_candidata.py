import json
import os
import re
import unittest
from collections import Counter

from fastapi.testclient import TestClient

from data.database import (Alumno, Anexo5Evento, Base, ColeccionInstitucional, EPPDoc, Escuela,
                           PlaneacionDoc, Usuario, get_engine, get_session)
from piloto_spa.backend.auth_service import hash_password
from piloto_spa.backend.main import app
from tools.captura_sheets_candidata import _formar, lecturas_consistentes
from tools.recuperacion_documental import Incompatible
from tools.sincronizar_candidata import CONFLICTOS, REVISIONES, sincronizar


class FuenteDoble(unittest.TestCase):
    def test_rechaza_fuente_en_edicion_y_no_consulta_pestanas_de_credenciales(self):
        libro = "x" * 30
        llamadas = Counter()
        visibles = ("Alumnos", "Planeaciones_Versiones", "EPP_Versiones", "Usuarios")

        def google(path, **params):
            if path == libro:
                llamadas["vuelta"] += 1
                return {"spreadsheetId": libro, "sheets": [{"properties": {"sheetId": i, "title": n,
                    "gridProperties": {"rowCount": 2, "columnCount": 2}}} for i, n in enumerate(visibles)]}
            self.assertTrue(path.endswith("/values:batchGet"))
            self.assertTrue(all("Usuarios" not in r for r in params["ranges"]))
            rangos = []
            for rango in params["ranges"]:
                if "!A1:" in rango:
                    values = [["ID_Alumno", "Dato"]]
                else:
                    values = [["ALU-QA", str(llamadas["vuelta"])]] if "Alumnos" in rango else []
                rangos.append({"range": rango, "values": values})
            return {"spreadsheetId": libro, "valueRanges": rangos}

        with self.assertRaisesRegex(Incompatible, "origen_cambio"):
            lecturas_consistentes(google, {"maestro": libro}, intentos=2)
        self.assertEqual(llamadas["vuelta"], 4)

    def test_certifica_dos_lecturas_iguales_del_libro_separado(self):
        libro = "c" * 30

        def google(path, **params):
            if path == libro:
                return {"spreadsheetId": libro, "sheets": [{"properties": {"sheetId": 8, "title": "Registros",
                    "gridProperties": {"rowCount": 2, "columnCount": 4}}}]}
            rangos = []
            for rango in params["ranges"]:
                values = ([["ID_Publicacion", "Especialista", "Fecha", "Actividad"]] if "!A1:" in rango else
                          [["QA-PUB", "Especialista ficticio", "2026-11-03", "Visita ficticia"]])
                rangos.append({"range": rango, "values": values})
            return {"spreadsheetId": libro, "valueRanges": rangos}
        corte, = lecturas_consistentes(google, {"cronogramas": libro})
        self.assertEqual(corte.modo, "sheets")
        self.assertIn(("QA-PUB", "Especialista ficticio"), corte.hojas["Cronogramas_Registros"])


class CorteEnPostgres(unittest.TestCase):
    def test_preview_dos_aplicaciones_estados_conflictos_y_ausencias(self):
        if not re.fullmatch(r"postgresql\+psycopg2://usaer_qa@127\.0\.0\.1:55491/usaer_epp_noviembre_qa_[a-f0-9]{8}",
                            os.environ.get("DATABASE_URL", "")):
            self.fail("El escenario requiere una base sintética desechable autorizada.")
        import secrets
        pwd = secrets.token_urlsafe(24)
        Base.metadata.create_all(get_engine(initialize_schema=False))
        with get_session() as db:
            self.assertEqual(db.query(Alumno).count(), 0)
            db.add_all([Escuela(id="ESC-QA1", nombre_escuela="Escuela ficticia"),
                        Alumno(id="QA-1", nombre_completo="Alumno ficticio", id_escuela="ESC-QA1",
                               nombre_escuela="Escuela ficticia"),
                        Usuario(id="QA-D", nombre="Dirección ficticia", usuario="qa.dir", rol="DIRECTOR",
                                password=hash_password(pwd)),
                        Usuario(id="QA-A", nombre="Apoyo ficticio", usuario="qa.apo", rol="APRENDIZAJE",
                                password=hash_password(pwd), escuelas_permitidas="ESC-QA1")])
            db.commit()

        def fila(ident, contenido, estado="ACTIVO"):
            return {"ID_Evento": ident, "Fecha": "2026-11-01", "ID_Alumno": "QA-1",
                    "ID_Escuela": "ESC-QA1", "Especialista": "Apoyo ficticio",
                    "Estado": estado, "Evento": contenido, "Escuela": "Escuela ficticia"}

        from hashlib import sha256
        plan = {"id": "QA-PLN", "cuenta": "qa.apo", "formato": "XXIII", "estado": "BORRADOR",
                "datos": {"ID_Escuela": "ESC-QA1", "Alumnos": [{"ID_Alumno": "QA-1"}]}}
        original = json.dumps(plan)
        diarios = {"Planeaciones_Versiones": [{
            "Documento": plan["id"], "Cuenta": "qa.apo", "Autor": "Apoyo ficticio", "Formato": "XXIII",
            "Estado": "BORRADOR", "Escuela_ID": "ESC-QA1", "Alumnos_JSON": '["QA-1"]', "Revision": "QA-R1",
            "Anterior": "", "Fecha": "2026-11-01", "Parte": "0", "Total": "1",
            "SHA256": sha256(original.encode()).hexdigest(), "Contenido": original,
        }], "EPP_Versiones": [{
            "Alumno": "QA-1", "Ciclo": "2026-2027", "Parte": "META", "Revision": "QA-EPP-R1",
            "Anterior": "", "Fecha": "2026-11-01", "Cuenta": "qa.apo", "Autor": "Apoyo ficticio",
            "Estado": "BORRADOR", "Contenido": '{"creada_por":"qa.apo"}',
        }]}

        def ejecutar(filas, aplicar):
            corte = _formar("maestro", "sheets", {"Anexo5_Eventos": filas, **diarios})
            with get_session() as db:
                resultado, = sincronizar(db, [corte], aplicar=aplicar)
                if aplicar:
                    db.commit()
                return resultado

        inicial = [fila("QA-CONFLICTO", "Original"), fila("QA-ESTADO", "Actividad")]
        self.assertEqual(ejecutar(inicial, False)["tipos"]["Anexo5_Eventos"]["alta_operativa"], 2)
        with get_session() as db:
            self.assertEqual(db.query(Anexo5Evento).count(), 0)
            self.assertEqual(db.query(ColeccionInstitucional).count(), 0)
        primera = ejecutar(inicial, True)
        self.assertGreater(primera["escrituras"], 0)
        self.assertEqual(primera["tipos"]["Planeaciones_Versiones"]["alta_operativa"], 1)
        self.assertEqual(primera["tipos"]["EPP_Versiones"]["alta_operativa"], 1)
        self.assertEqual(ejecutar(inicial, True)["escrituras"], 0)
        with get_session() as db:
            db.get(Anexo5Evento, "QA-CONFLICTO").evento = "Edición legítima PostgreSQL"
            db.commit()
        nuevo = [fila("QA-CONFLICTO", "Edición legítima Sheets"), fila("QA-ESTADO", "Actividad", "ANULADO")]
        segunda = ejecutar(nuevo, True)
        tot = segunda["tipos"]["Anexo5_Eventos"]
        self.assertEqual(tot["edicion_en_ambos_origenes"], 1)
        self.assertEqual(tot["actualizacion_operativa"], 1)
        self.assertEqual(ejecutar(nuevo, True)["escrituras"], 0)
        self.assertEqual(ejecutar(nuevo[:1], True)["ausentes_no_borrados"], 1)
        with get_session() as db:
            self.assertEqual(db.get(Anexo5Evento, "QA-CONFLICTO").evento, "Edición legítima PostgreSQL")
            self.assertEqual(db.get(Anexo5Evento, "QA-ESTADO").estado, "ANULADO")
            self.assertEqual(db.get(PlaneacionDoc, "QA-PLN").revision, "QA-R1")
            self.assertEqual(db.query(EPPDoc).one().estado, "BORRADOR")
            self.assertEqual(db.query(ColeccionInstitucional).filter_by(modulo=REVISIONES).count(), 1)
            ref = db.query(ColeccionInstitucional).filter_by(modulo=CONFLICTOS).one().registro_id

        c = TestClient(app)
        def ingresar(usuario):
            respuesta = c.post("/api/auth/login", json={"usuario": usuario, "password": pwd})
            self.assertEqual(respuesta.status_code, 200)
            return {"Authorization": "Bearer " + respuesta.json()["token"]}
        apoyo, director = (ingresar(x) for x in ("qa.apo", "qa.dir"))
        self.assertEqual(c.get("/api/direccion/sincronizacion", headers=apoyo).status_code, 403)
        r = c.get("/api/direccion/sincronizacion/" + ref, headers=director).json()
        self.assertEqual(r["postgresql"]["evento"], "Edición legítima PostgreSQL")
        origen = c.get("/api/direccion/archivo-historico/" + r["origen"], headers=director).json()
        self.assertEqual(origen["filas"][0]["Evento"], "Edición legítima Sheets")
        self.assertIn("sheets:maestro", c.get("/api/direccion/sincronizacion", headers=director).json()["cortes"])

        viejo = _formar("maestro", "xlsx", {"Anexo5_Eventos": [fila("QA-SOLO-HISTORICO", "Sin cambios")]})
        reciente = _formar("maestro", "xlsx", {"Anexo5_Eventos": [
            fila("QA-SOLO-HISTORICO", "Sin cambios"), fila("QA-XLSX-NUEVO", "Captura nueva"),
        ]})
        with get_session() as db:
            sincronizar(db, [viejo], aplicar=True, solo_referencia=True)
            db.commit()
            sincronizar(db, [reciente], aplicar=True, referencias=[viejo])
            db.commit()
            self.assertIsNone(db.get(Anexo5Evento, "QA-SOLO-HISTORICO"))
            self.assertIsNotNone(db.get(Anexo5Evento, "QA-XLSX-NUEVO"))
            self.assertEqual(sincronizar(db, [reciente], aplicar=True, referencias=[viejo])[0]["escrituras"], 0)


if __name__ == "__main__":
    unittest.main()
