"""Ejecuta el recorrido Edge solo contra una base PostgreSQL sintética recién creada."""
import os
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import threading
import time

import uvicorn

sys.path.insert(0, str(Path(__file__).parent))
from test_spa_epp_viva import EppYPlaneacion
from data.database import Alumno, Anexo5Evento, ColeccionInstitucional, Escuela, Usuario, get_session
from piloto_spa.backend.auth_service import hash_password
from tools.ampliar_recuperacion_historica import _registro_archivo
from tools.captura_sheets_candidata import _formar
from tools.sincronizar_candidata import sincronizar


def pdf_referencia(salida):
    from piloto_spa.backend.auth_service import SessionUser
    from piloto_spa.backend.epp_viva import vista_partes
    from piloto_spa.backend.main import _cargar_epp

    usuario = SessionUser(id_usuario="QA-5", nombre="Dirección ficticia", usuario="qa.5",
                          rol="DIRECTOR", escuelas_permitidas=[], director=True, area="")
    doc, a = _cargar_epp("ALU-QA1", "2026-2027", usuario)
    doc["partes"] = vista_partes(doc)
    campos = {"Nombre_Completo": "nombre_completo", "Nombre_Escuela": "escuela", "Nivel_Educativo": "nivel",
              "CURP": "curp", "Grado": "grado", "Grupo": "grupo"}
    alumno = {k: a.get(v) for k, v in campos.items()}
    origen = "b6f7fd68a379381e1bf949f1ab3b6e0db10ae516:documents/epp.py"
    original = subprocess.check_output(["git", "show", origen])
    modulo = {"__file__": str(Path("documents/epp.py").resolve())}
    exec(compile(original, origen, "exec"), modulo)
    # Se compara la composición con datos idénticos; no se cargan antecedentes
    # ni firmas de producción desde el generador de referencia.
    modulo["precargar"] = lambda contenido, *_: contenido
    Path(salida).write_bytes(modulo["generar_pdf"](doc, alumno, incluir_firmas=False))


def main():
    EppYPlaneacion.setUpClass()
    clave = EppYPlaneacion.password
    with get_session() as db:
        db.add(Escuela(id="ESC-002", nombre_escuela="Escuela sintética compartida"))
        for i, letra in ((6, "A"), (7, "B")):
            docente = f"Docente ficticia {letra}"
            db.add(Usuario(id=f"QA-{i}", usuario=f"qa.{i}", nombre=docente,
                           password=hash_password(clave), rol="APRENDIZAJE", escuelas_permitidas="ESC-002"))
            db.add(Alumno(id=f"ALU-QA-{letra}", nombre_completo=f"Escolar ficticio {letra}",
                          id_escuela="ESC-002", maestra_apoyo=docente, grado="2", grupo="A"))
        db.add(ColeccionInstitucional(**_registro_archivo("Anexo5_Eventos", ("QA-DUP",),
            [{"Evento": "Versión sintética uno"}, {"Evento": "Versión sintética dos"}],
            "id_repetido_con_contenido_distinto")))
        dia = "2026-11-04"
        db.add(ColeccionInstitucional(**_registro_archivo("Borradores_Cronogramas",
            ("qa-crono-origen", "Profesional ficticio 1", "2026-11"),
            [{"ID_Version": "qa-crono-origen", "Guardado_En": "2026-11-01T09:00:00-06:00",
              "Dias_JSON": json.dumps({dia: {"escuela": "Escuela ficticia 1", "actividad": "Actividad de origen"}})}],
            "pendiente_proyeccion")))
        db.add(ColeccionInstitucional(**_registro_archivo("Cronogramas_Registros",
            ("qa-publicacion", "Profesional ficticio 1"),
            [{"ID_Publicacion": "qa-publicacion", "Fecha": dia, "Marca temporal": "2026-11-01",
              "Especialista": "Profesional ficticio 1", "Escuela": "Escuela ficticia 1",
              "Actividad": "Publicación sintética anterior", "Estado": "SUSTITUIDO"}],
            "pendiente_proyeccion")))
        filas = []
        for rev, anterior, nota in (("qa-primera", "", "Registro inicial"), ("qa-segunda", "qa-primera", "Registro ampliado")):
            plan = {"id": "historica-ind", "cuenta": "qa.0", "formato": "XXIII", "estado": "BORRADOR",
                    "datos": {"ID_Escuela": "ESC-QA1", "Alumnos": [{"ID_Alumno": "ALU-QA1"}]},
                    "textos": {"Evaluación": nota}}
            dato = json.dumps(plan, ensure_ascii=False)
            filas.append({"Documento": plan["id"], "Cuenta": "qa.0", "Formato": "XXIII", "Estado": "BORRADOR",
                          "Escuela_ID": "ESC-QA1", "Alumnos_JSON": '["ALU-QA1"]', "Autor": "Profesional ficticio",
                          "Revision": rev, "Anterior": anterior, "Fecha": "2026-11-01", "Parte": "0", "Total": "1",
                          "SHA256": sha256(dato.encode()).hexdigest(), "Contenido": dato})
        db.add(ColeccionInstitucional(**_registro_archivo("Planeaciones_Versiones", ("historica-ind",), filas,
                                                          "diario_planeacion")))
        db.commit()
    with get_session() as db:
        fila = {"ID_Evento": "QA-SYNC-EDGE", "Fecha": "2026-11-11", "ID_Alumno": "ALU-QA1",
                "ID_Escuela": "ESC-QA1", "Escuela": "Escuela ficticia 1",
                "Especialista": "Profesional ficticio 0", "Estado": "ACTIVO", "Evento": "Origen inicial"}
        sincronizar(db, [_formar("maestro", "sheets", {"Anexo5_Eventos": [fila]})], aplicar=True)
        db.commit()
        db.get(Anexo5Evento, "QA-SYNC-EDGE").evento = "Edición local conservada"
        db.commit()
        fila["Evento"] = "Edición de fuente conservada"
        sincronizar(db, [_formar("maestro", "sheets", {"Anexo5_Eventos": [fila]})], aplicar=True)
        db.commit()
    # Solo el proceso QA sustituye el catálogo de perfiles; no hay identidades reales en la prueba.
    import services.cronogramas as crono
    from piloto_spa.backend import cronogramas_historicos
    cronogramas_historicos.ESCUELAS_USAER = {"Escuela ficticia 1": "ESC-QA1"}
    crono.perfil_especialista = lambda nombre, rol: (
        {"nombre": nombre, "area": "Psicología", "escuelas": ["Escuela ficticia 1"]}
        if nombre == "Profesional ficticio 1" and rol == "PSICOLOGIA" else None)
    servidor = uvicorn.Server(uvicorn.Config("piloto_spa.backend.main:app", host="127.0.0.1", port=18173,
                                             log_level="error", access_log=False))
    hilo = threading.Thread(target=servidor.run, daemon=True)
    hilo.start()
    for _ in range(200):
        if servidor.started:
            break
        if not hilo.is_alive():
            raise RuntimeError("No arrancó la SPA sintética.")
        time.sleep(0.025)
    else:
        raise RuntimeError("No arrancó la SPA sintética.")
    try:
        env = dict(os.environ, USAER_NAVEGADOR_URL="http://127.0.0.1:18173", USAER_NAVEGADOR_CLAVE=clave)
        ruta = Path(__file__).with_suffix(".cjs")
        codigo = subprocess.run(["node", str(ruta)], env=env, timeout=240).returncode
        if not codigo and os.environ.get("USAER_NAVEGADOR_PDF"):
            import pymupdf
            salida = Path(os.environ["USAER_NAVEGADOR_PDF"])
            with pymupdf.open(salida) as pdf:
                texto = " ".join(pagina.get_text() for pagina in pdf)
            assert "Nivel educativo: Primaria" in texto
            for area in ("Aprendizaje", "Psicología", "Comunicación", "Trabajo Social", "Conclusión"):
                assert f"Registro sintético {area}" in texto
            pdf_referencia(salida.with_name("epp-streamlit-referencia-sintetica.pdf"))
        return codigo
    finally:
        servidor.should_exit = True
        hilo.join(timeout=10)


if __name__ == "__main__":
    raise SystemExit(main())
